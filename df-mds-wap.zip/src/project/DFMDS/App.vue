<template>
    <div id="app">
        <router-view id="Router" />
    </div>
</template>

<style lang="scss">
</style>
