<template>
    <div />
</template>

<script>
export default {
    name: 'ManHoursReadyTime',
    components: {},
    data() {
        return {};
    },
    computed: {},
    methods: {}
};
</script>

<style scoped></style>
