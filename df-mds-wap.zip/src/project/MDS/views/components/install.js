import remark from './Remark.vue';
const install = {
    install: function(Vue) {
        Vue.component('Remark', remark);
    }
};
export default install;
