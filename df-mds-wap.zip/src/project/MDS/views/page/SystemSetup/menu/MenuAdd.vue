<template>
    <el-dialog :title="!dataForm.id ? '新增' : '修改'" :close-on-click-modal="false" :visible.sync="visible">
        <el-form ref="dataForm" :model="dataForm" :rules="dataRule" label-width="120px" @keyup.enter.native="dataFormSubmit()">
            <el-form-item label="ID" prop="id">
                <el-input v-model="dataForm.id" placeholder="请输入id" />
            </el-form-item>
            <el-form-item label="类型" prop="type">
                <el-radio-group v-model="dataForm.type">
                    <el-radio v-for="(subType, index) in dataForm.typeList" :key="index" :label="index">
                        {{ subType }}
                    </el-radio>
                </el-radio-group>
            </el-form-item>
            <el-form-item :label="dataForm.typeList[dataForm.type] + '名称'" prop="name">
                <el-input v-model="dataForm.name" :placeholder="dataForm.typeList[dataForm.type] + '名称'" />
            </el-form-item>
            <el-form-item label="上级菜单" prop="parentName">
                <el-popover ref="menuListPopover" placement="bottom-start" trigger="click" style="height: 100%; overflow: auto;">
                    <el-tree ref="menuListTree" :data="menuList" :props="menuListTreeProps" node-key="menuId" :default-expand-all="false" :highlight-current="true" :expand-on-click-node="false" @current-change="menuListTreeCurrentChangeHandle" />
                </el-popover>
                <el-input v-model="dataForm.parentName" v-popover:menuListPopover :readonly="true" placeholder="点击选择上级菜单" class="menu-list__input" />
            </el-form-item>
            <el-form-item v-if="dataForm.type === 1 || dataForm.type === 3 || dataForm.type === 0 || dataForm.type === 4" label="菜单路由" prop="url">
                <el-input v-model="dataForm.url" placeholder="菜单路由" />
            </el-form-item>
            <el-form-item v-if="dataForm.type !== 0" label="授权标识" prop="perms">
                <el-input v-model="dataForm.perms" placeholder="多个用逗号分隔, 如: user:list,user:create" />
            </el-form-item>
            <el-form-item v-if="dataForm.type !== 2" label="排序号" prop="orderNum">
                <el-input-number v-model="dataForm.orderNum" controls-position="right" :min="0" label="排序号" />
            </el-form-item>
            <el-form-item v-if="dataForm.type !== 2" label="菜单图标" prop="icon">
                <el-row>
                    <el-col :span="22">
                        <el-popover ref="iconListPopover" placement="bottom-start" trigger="click" popper-class="mod-menu__icon-popover">
                            <div class="mod-menu__icon-list">
                                <el-button
                                    v-for="(item, index) in iconList"
                                    :key="index"
                                    :class="{
                                        'is-active': item === dataForm.icon,
                                    }"
                                    @click="iconActiveHandle(item)"
                                >
                                    <template>
                                        <em :class="item" class="iconfont" style="font-size: 20px;" />
                                    </template>
                                </el-button>
                            </div>
                        </el-popover>
                        <el-input v-model="dataForm.icon" v-popover:iconListPopover :readonly="true" placeholder="菜单图标名称" class="icon-list__input" />
                    </el-col>
                </el-row>
            </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
            <el-button @click="visible = false">取消</el-button>
            <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
        </span>
    </el-dialog>
</template>

<script>
import { treeDataTranslate } from '@/net/validate';
import { SYSTEMSETUP_API } from '@/api/api';
export default {
    name: 'MenuAdd',
    components: {},
    data() {
        const validateUrl = (rule, value, callback) => {
            if (this.dataForm.type === 1 && !/\S/.test(value)) {
                return callback(new Error('菜单URL不能为空'));
            }
                return callback();

        };
        return {
            iconList: [
                'factory-shouye',
                'factory-shezhi',
                'factory-luru',
                'factory-shenhe',
                'factory-baobiao',
                'factory-yibiao',
                'factory-icon-test',
                'factory-baozhuang',
                'factory-filter',
                'factory-chechuangjiqiren',
                'factory-qiyaguanjianhua',
                'factory-chaohuo',
                'factory-guanquguanli',
                'factory-air-compressor',
                'factory-shajun',
                'factory-guolv',
                'factory-chuiping',
                'factory-yuanshui',
                'factory-calc'
            ],
            visible: false,
            type: true,
            dataForm: {
                id: 0,
                type: 1,
                typeList: ['目录', '菜单', '按钮', '三级页面', '看板'],
                name: '',
                parentId: 0,
                parentName: '',
                url: '',
                perms: '',
                orderNum: 0,
                icon: '',
                iconList: []
            },
            dataRule: {
                id: [
                    {
                        required: true,
                        message: '菜单名称不能为空',
                        trigger: 'blur'
                    }
                ],
                name: [
                    {
                        required: true,
                        message: '菜单名称不能为空',
                        trigger: 'blur'
                    }
                ],
                parentName: [
                    {
                        required: true,
                        message: '上级菜单不能为空',
                        trigger: 'change'
                    }
                ],
                url: [{ validator: validateUrl, trigger: 'blur' }]
            },
            menuList: [],
            menuListTreeProps: {
                label: 'name',
                children: 'children'
            },
            submitType: true
        };
    },
    computed: {},
    mounted() {
    //    mounted
    },
    methods: {
        init(id) {
            this.$http(`${SYSTEMSETUP_API.MENUSELECT_API}`, 'GET', {})
                .then(({ data }) => {
                    this.menuList = treeDataTranslate(data.menuList, 'menuId');
                })
                .then(() => {
                    this.visible = true;
                    this.$nextTick(() => {
                        this.$refs.dataForm.resetFields();
                        this.dataForm.id = id || 0;
                    });
                })
                .then(() => {
                    if (!this.dataForm.id) {
                        // 新增
                        this.menuListTreeSetCurrentNode();
                        this.type = true;
                    } else {
                        // 修改
                        this.type = false;
                        this.$http(`${SYSTEMSETUP_API.MENUINFO_API}/${this.dataForm.id}`, 'GET', {}).then(({ data }) => {
                            this.dataForm.id = data.menu.menuId;
                            this.dataForm.type = Number(data.menu.type);
                            this.dataForm.name = data.menu.name;
                            this.dataForm.parentId = data.menu.parentId;
                            this.dataForm.url = data.menu.url;
                            this.dataForm.perms = data.menu.perms;
                            this.dataForm.orderNum = data.menu.orderNum;
                            this.dataForm.icon = data.menu.icon;
                            this.menuListTreeSetCurrentNode();
                        });
                    }
                });
        },
        // 菜单树选中
        menuListTreeCurrentChangeHandle(data) {
            this.dataForm.parentId = data.menuId;
            this.dataForm.parentName = data.name;
        },
        // 菜单树设置当前选中节点
        menuListTreeSetCurrentNode() {
            this.$refs.menuListTree.setCurrentKey(this.dataForm.parentId);
            this.dataForm.parentName = (this.$refs.menuListTree.getCurrentNode() || {})['name'];
        },
        // 图标选中
        iconActiveHandle(iconName) {
            this.dataForm.icon = iconName;
        },
        // 表单提交
        dataFormSubmit() {
            if (this.submitType) {
                this.submitType = false;
                this.$refs['dataForm'].validate(valid => {
                    if (valid) {
                        this.$http(`${this.type ? SYSTEMSETUP_API.MENUADD_API : SYSTEMSETUP_API.MENUUPDATE_API}`, 'POST', {
                            menuId: this.dataForm.id || null,
                            type: this.dataForm.type,
                            name: this.dataForm.name,
                            parentId: this.dataForm.parentId,
                            url: this.dataForm.url,
                            perms: this.dataForm.perms,
                            orderNum: this.dataForm.orderNum,
                            icon: this.dataForm.icon
                        }).then(({ data }) => {
                            if (data && data.code === 0) {
                                this.$successToast('操作成功');
                                this.submitType = true;
                                this.visible = false;
                                this.$emit('refreshDataList');
                            } else {
                                this.submitType = true;
                                this.$errorToast(data.msg);
                            }
                        });
                    } else {
                        this.submitType = true;
                    }
                });
            }
        }
    }
};
</script>

<style lang="scss">
.mod-menu {
    .menu-list__input,
    .icon-list__input {
        > .el-input__inner {
            cursor: pointer;
        }
    }
    &__icon-popover {
        max-width: 370px;
    }
    &__icon-list {
        max-height: 180px;
        margin: -8px 0 0 -8px;
        padding: 0;
        > .el-button {
            margin: 8px 0 0 8px;
            padding: 8px;
            > span {
                display: inline-block;
                width: 18px;
                height: 18px;
                font-size: 18px;
                vertical-align: middle;
            }
        }
    }
    .icon-list__tips {
        color: #e6a23c;
        font-size: 18px;
        text-align: center;
        cursor: pointer;
    }
}
.el-dialog__body {
    padding: 10px 20px;
}
</style>
