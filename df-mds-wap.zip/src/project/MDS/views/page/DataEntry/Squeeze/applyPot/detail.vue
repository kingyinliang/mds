<template>
    <div class="header_main">
        <mds-card title="申请基本信息" name="applyDetail">
            <el-row type="flex">
                <el-col class="header-form" :span="24">
                    <el-form :model="formHeader" size="small" :inline="true" label-position="right" label-width="100px" class="topform multi_row">
                        <el-form-item label="生产工厂：">
                            <el-select v-model="formHeader.factory" class="selectwpx" style="width: 140px;" :disabled="!isEdit" @change="changeOptions('factory')">
                                <el-option label="请选择" value="" />
                                <el-option v-for="sole in factoryList" :key="sole.deptId" :label="sole.deptName" :value="sole.deptId" />
                            </el-select>
                        </el-form-item>
                        <el-form-item label="生产车间：">
                            <el-select v-model="formHeader.workShop" class="selectwpx" style="width: 140px;" :disabled="!isEdit" @change="changeOptions('workshop')">
                                <el-option label="请选择" value="" />
                                <el-option v-for="sole in workshopList" :key="sole.deptId" :label="sole.deptName" :value="sole.deptId" />
                            </el-select>
                        </el-form-item>
                        <el-form-item label="酱醪名称：">
                            <el-select v-model="formHeader.materialCode" filterable class="selectwpx" style="width: 140px;" :disabled="!isEdit" @change="changeOptions('material')">
                                <el-option label="请选择" value="" />
                                <el-option v-for="sole in materialList" :key="sole.materialCode" :label="sole.materialName + ' ' + sole.materialCode" :value="sole.materialCode" />
                            </el-select>
                        </el-form-item>
                        <el-form-item label="半成品类别：" label-width="100px">
                            <el-select v-model="formHeader.halfType" filterable class="selectwpx" style="width: 140px;" :disabled="!isEdit" @change="changeOptions('halfType')">
                                <el-option label="请选择" value="" />
                                <el-option v-for="sole in halfTypeList" :key="sole.halfType" :label="sole.halfName" :value="sole.halfType" />
                            </el-select>
                        </el-form-item>
                        <el-form-item label="申请数量：" label-width="100px">
                            <el-input v-model.number="formHeader.amount" type="number" size="small" style="width: 140px;" :disabled="!isEdit" />
                        </el-form-item>
                        <el-form-item label="生产日期：">
                            <el-date-picker v-model="formHeader.productDate" type="date" value-format="yyyy-MM-dd" style="width: 140px;" :disabled="!isEdit" />
                        </el-form-item>
                        <el-form-item label="申请编号：">
                            <p class="header-form_input">
                                {{ formHeader.applyNo }}
                            </p>
                        </el-form-item>
                        <el-form-item label="申请时间：">
                            <p class="header-form_input">
                                {{ formHeader.changed }}
                            </p>
                        </el-form-item>
                        <el-form-item label="订单状态：">
                            <p class="header-form_input">
                                {{ formHeader.status === 'saved' ? '已保存' : formHeader.status === 'submit' ? '已提交' : formHeader.status }}
                            </p>
                        </el-form-item>
                    </el-form>
                </el-col>
            </el-row>
            <el-row>
                <el-col :span="24">
                    <el-form :model="formHeader" size="small" :inline="true" label-position="right" label-width="100px" class="topform">
                        <el-form-item label="备注：">
                            <el-input v-model.trim="formHeader.remark" type="textarea" :rows="2" style="width: 500px;" :disabled="!isEdit" placeholder="请输入内容" />
                        </el-form-item>
                    </el-form>
                </el-col>
            </el-row>
        </mds-card>
        <mds-card title="申请反馈信息" name="applyFeedback">
            <el-table class="newTable" header-row-class-name="tableHead" :data="detailList" border tooltip-effect="dark">
                <el-table-column type="index" label="序号" width="55" fixed />
                <el-table-column label="申请编码" min-width="140">
                    <template slot-scope="scope">
                        {{ scope.row.applyNo }}
                    </template>
                </el-table-column>
                <el-table-column label="罐号" :show-overflow-tooltip="true" min-width="120">
                    <template slot-scope="scope">
                        {{ scope.row.holderName }}
                    </template>
                </el-table-column>
                <el-table-column label="订单类型" :show-overflow-tooltip="true" min-width="120">
                    <template slot-scope="scope">
                        {{ scope.row.orderTypeName }}
                    </template>
                </el-table-column>
                <el-table-column label="发酵天数/天" :show-overflow-tooltip="true" min-width="100">
                    <template slot-scope="scope">
                        {{ scope.row.ferDays }}
                    </template>
                </el-table-column>
                <el-table-column label="半成品类别" :show-overflow-tooltip="true" min-width="130">
                    <template slot-scope="scope">
                        {{ scope.row.halfType }}
                    </template>
                </el-table-column>
                <el-table-column label="批次" min-width="110">
                    <template slot-scope="scope">
                        {{ scope.row.batch }}
                    </template>
                </el-table-column>
                <el-table-column label="备注" min-width="130">
                    <template slot-scope="scope">
                        {{ scope.row.remark }}
                    </template>
                </el-table-column>
                <el-table-column label="确认人员" min-width="150">
                    <template slot-scope="scope">
                        {{ scope.row.changer }}
                    </template>
                </el-table-column>
                <el-table-column label="确认时间" min-width="170" :show-overflow-tooltip="true">
                    <template slot-scope="scope">
                        {{ scope.row.changed }}
                    </template>
                </el-table-column>
            </el-table>
        </mds-card>
        <redact-box>
            <template slot="button">
                <el-button v-if="isAuth('fer:openHolder:mySaveOrUpdate')" type="primary" size="small" :disabled="!isEdit" @click="save()">
                    保存
                </el-button>
                <el-button v-if="isAuth('fer:openHolder:submit')" type="primary" size="small" :disabled="!isEdit" @click="submit()">
                    提交
                </el-button>
            </template>
        </redact-box>
    </div>
</template>

<script lang="ts">
import { BASICDATA_API, SQU_API, FERMENTATION_API } from '@/api/api';
import { Vue, Component } from 'vue-property-decorator';
import { headanimation, dateFormat } from '@/net/validate';
@Component({
    components: {}
})
export default class Index extends Vue {
    // 将common中的参数复制一份到本地
    // NEEDTODO
    /* eslint-disable no-invalid-this */
    params = JSON.parse(JSON.stringify(this.$store.state.common.SqueezeApplyPot));
    formHeader = {
        id: this.params.applyId,
        status: '',
        factory: this.params.factoryId,
        factoryCode: '',
        workShop: this.params.workshopId,
        applyNo: '',
        materialCode: '',
        materialName: '',
        halfType: '',
        halfName: '',
        productDate: dateFormat(new Date(), 'yyyy-MM-dd'),
        amount: 0,
        remark: '',
        confirmFlag: 0,
        delFlag: 0,
        created: '',
        creator: '',
        changed: '',
        changer: ''
    };

    factoryList = [];
    workshopList = [];
    // 酱醪列表
    materialList = [];
    // 半成品列表
    halfTypeList = [];
    detailList = [];
    searched = false;
    mounted() {
        headanimation(Vue.prototype.$);
        // 获取表头数据
        this.getHeaderForm(this.formHeader.id);
        this.getDetailList(this.formHeader.id);
        this.getFactory();
        this.getWorkshop(this.formHeader.factory);
        this.getMaterialList(this.formHeader.factory);
        this.getHalfTypeList(this.formHeader.factory, this.formHeader.materialCode);
        // this.getFermentPot(this.params.factoryId)
    }

    get isEdit() {
        // 提交之后不能再修改
        return this.formHeader.status !== 'submit';
    }

    changeOptions(flag: string) {
        if (flag === 'factory') {
            this.formHeader.workShop = '';
            this.formHeader.materialCode = '';
            this.formHeader.materialName = '';
            this.formHeader.halfType = '';
            this.formHeader.halfName = '';
            this.getWorkshop(this.formHeader.factory);
            this.getMaterialList(this.formHeader.factory);
            this.getHalfTypeList(this.formHeader.factory, this.formHeader.materialCode);
        } else if (flag === 'workshop') {
            // DO NOTHING
        } else if (flag === 'material') {
            const item: any = this.materialList.find((ele: any) => ele.materialCode === this.formHeader.materialCode);// eslint-disable-line
            this.formHeader.materialName = item ? item.materialName : '';
            this.formHeader.halfType = '';
            this.formHeader.halfName = '';
            this.getHalfTypeList(this.formHeader.factory, this.formHeader.materialCode);
        } else if (flag === 'halfType') {
            const item: any = this.halfTypeList.find((ele: any) => ele.halfType === this.formHeader.halfType);// eslint-disable-line
            this.formHeader.halfName = item ? item.halfName : '';
        }
    }

    getHeaderForm(applyId) {
        if (applyId) {
            // 有applyId才取表头数据
            const params = { id: applyId };
            Vue.prototype.$http(`${SQU_API.POT_APPLY_LIST_API}`, `POST`, params).then(res => {
                if (res.data.code === 0) {
                    if (res.data.page.list && res.data.page.list.length > 0) {
                        this.formHeader = res.data.page.list[0];
                    }
                } else {
                    this.$notify.error({
                        title: '错误',
                        message: res.data.msg
                    });
                }
            });
        }
    }

    getDetailList(applyId) {
        this.detailList = [];
        if (applyId) {
            // 有applyId才取详情数据
            Vue.prototype
                .$http(`${SQU_API.POT_APPLY_DETAIL_API}`, `POST`, {
                    openId: applyId
                })
                .then(res => {
                    if (res.data.code === 0) {
                        this.detailList = res.data.list;
                    } else {
                        this.$notify.error({
                            title: '错误',
                            message: res.data.msg
                        });
                    }
                });
        }
    }

    // 获取工厂
    getFactory() {
        this.factoryList = [];
        Vue.prototype.$http(`${BASICDATA_API.FINDORG_API}?code=factory`, `POST`, {}, false, false, false).then(res => {
            if (res.data.code === 0) {
                this.factoryList = res.data.typeList;
            } else {
                this.$notify.error({ title: '错误', message: res.data.msg });
            }
        });
    }

    // 根据工厂获车间
    getWorkshop(fid: string) {
        this.workshopList = [];
        if (fid) {
            Vue.prototype.$http(`${BASICDATA_API.FINDORGBYID_API}`, 'POST', { deptId: fid, deptName: '压榨' }, false, false, false).then(res => {
                if (res.data.code === 0) {
                    this.workshopList = res.data.typeList;
                } else {
                    this.$notify.error({
                        title: '错误',
                        message: res.data.msg
                    });
                }
            });
        }
    }

    getMaterialList(factory) {
        this.materialList = [];
        // this.$http(`${FERMENTATION_API.FORRECIPIENTSHOLDER_API}`, 'POST').then(({data}) => {
        //   if (data.code === 0) {
        //     this.MaterialType = data.productsInfo
        //   } else {
        //     this.$notify.error({title: '错误', message: data.msg})
        //   }
        // })
        if (factory) {
            Vue.prototype.$http(`${FERMENTATION_API.FORRECIPIENTSHOLDER_API}`, 'POST', { factory }, false, false, false).then(({ data }) => {
                if (data.code === 0) {
                    this.materialList = data.productsInfo;
                } else {
                    this.$notify.error({ title: '错误', message: data.msg });
                }
            });
        }
    }

    getHalfTypeList(factory, materialCode) {
        this.halfTypeList = [];
        if (factory && materialCode) {
            Vue.prototype.$http(`${BASICDATA_API.CATEGORY_SORTLIST}`, 'POST', { factory, materialCode }, false, false, false).then(res => {
                if (res.data.code === 0) {
                    this.halfTypeList = res.data.ferList;
                } else {
                    this.$notify.error({
                        title: '错误',
                        message: res.data.msg
                    });
                }
            });
        }
    }

    save() {
        if (this.validate()) {
            this.formHeader.status = 'saved';
            Vue.prototype.$http(`${SQU_API.POT_APPLY_DETAIL_SAVE_API}`, 'POST', this.formHeader).then(res => {
                if (res.data.code === 0) {
                    this.getHeaderForm(res.data.id);
                    this.getDetailList(res.data.id);
                    this.$notify({
                        title: '成功',
                        message: '保存成功',
                        type: 'success'
                    });
                } else {
                    this.$notify.error({
                        title: '错误',
                        message: res.data.msg
                    });
                }
            });
        }
    }

    submit() {
        if (this.validate()) {
            this.$confirm('确认提交该订单, 是否继续?', '提交订单', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.formHeader.status = 'submit';
                Vue.prototype.$http(`${SQU_API.POT_APPLY_DETAIL_SAVE_API}`, 'POST', this.formHeader).then(res => {
                    if (res.data.code === 0) {
                        this.getHeaderForm(res.data.id);
                        this.getDetailList(res.data.id);
                        this.$notify({
                            title: '成功',
                            message: '提交成功',
                            type: 'success'
                        });
                    } else {
                        this.$notify.error({
                            title: '错误',
                            message: res.data.msg
                        });
                    }
                });
            }).catch(() => {
                // this.$infoToast('已取消删除');
            });
        }
    }

    validate() {
        if (!this.formHeader.factory) {
            Vue.prototype.$warningToast('请选择工厂');
            return false;
        }
        if (!this.formHeader.workShop) {
            Vue.prototype.$warningToast('请选择车间');
            return false;
        }
        if (!this.formHeader.materialCode) {
            Vue.prototype.$warningToast('请选择酱醪');
            return false;
        }
        // if (!this.formHeader.halfType) {
        //   this.$message.error('请选择半成品类别')
        //   return false
        // }
        if (!this.formHeader.amount) {
            Vue.prototype.$warningToast('请填写申请数量');
            return false;
        }
        if (!this.formHeader.productDate) {
            Vue.prototype.$warningToast('请选择生产日期');
            return false;
        }
        return true;
    }
    // @Watch('formHeader.factory')
    // onFactoryValue (newVal: string, oldVal: string) {
    //   this.formHeader.workShop = ''
    //   // this.formHeader.halfType = ''
    //   // this.formHeader.halfName = ''
    //   this.formHeader.materialCode = ''
    //   this.formHeader.materialName = ''
    //   this.getWorkshop(newVal)
    //   this.getMaterialList(newVal)
    //   // this.getHalfTypeList(newVal, this.formHeader.materialCode)
    //   // this.getFermentPot(newVal)
    // }
    // @Watch('formHeader.materialCode')
    // onMaterialCode (newVal: string, oldVal: string) {
    //   // this.formHeader.halfType = ''
    //   // this.formHeader.halfName = ''
    //   this.getHalfTypeList(this.formHeader.factory, newVal)
    //   // this.getFermentPot(newVal)
    // }
}
</script>

<style lang="scss">
.topform {
    .el-form-item__content {
        height: 32px;
        border-bottom: 1px solid #d8d8d8;
    }
}
</style>
<style lang="scss" scoped>
@import "@/assets/scss/_common.scss";
.header-form {
    .header-form_input {
        width: 140px;
        overflow: hidden;
        color: rgba(0, 0, 0, 0.85);
        font-weight: 400;
        font-size: 14px;
        font-family: PingFangSC-Regular, sans-serif;
        white-space: nowrap;
        text-overflow: ellipsis;
    }
}
</style>
