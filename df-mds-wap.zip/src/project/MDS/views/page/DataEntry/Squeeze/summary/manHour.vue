<template>
    <div>
        <mds-card title="工时" name="summeryHour">
            <template slot="titleBtn">
                <el-button type="primary" style="float: right;" size="small" :disabled="!isRedact" @click="GetTime">
                    获取工时
                </el-button>
            </template>
            <el-table ref="table1" class="newTable" header-row-class-name="tableHead" border :data="timeDate" tooltip-effect="dark" @row-dblclick="GetLog">
                <el-table-column label="状态" width="95">
                    <template slot-scope="scope">
                        <span
                            :style="{
                                color: scope.row.status === 'noPass' ? 'red' : scope.row.status === 'checked' ? '#67C23A' : '',
                            }"
                        >{{ scope.row.status === 'noPass' ? '审核不通过' : scope.row.status === 'saved' ? '已保存' : scope.row.status === 'submit' ? '已提交' : scope.row.status === 'checked' ? '通过' : scope.row.status === '已同步' ? '未录入' : '未录入' }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="生产订单" width="120" prop="orderNo" />
                <el-table-column label="工序" width="120" prop="processIdName" />
                <el-table-column label="生产品项" prop="ssssss" :show-overflow-tooltip="true">
                    <template slot-scope="scope">
                        {{ scope.row.materialName + ' ' + scope.row.materialCode }}
                    </template>
                </el-table-column>
                <el-table-column label="入库量" width="120" prop="inPotAmount" />
                <el-table-column label="准备工时" width="120" prop="confActivity1" />
                <el-table-column label="人工工时" width="120" prop="confActivity3" />
                <el-table-column label="机器工时" width="120" prop="confActivity2">
                    <template slot-scope="scope">
                        <el-input v-model="scope.row.confActivity2" size="small" placeholder="手工录入" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked' && scope.row.isVerBack !== '1')" />
                    </template>
                </el-table-column>
                <el-table-column label="单位" width="50" prop="confActiUnit1" />
                <el-table-column label="操作" width="50" fixed="right">
                    <template slot-scope="scope">
                        <el-button type="text" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked' && scope.row.isVerBack !== '1')" @click="BackTime(scope.row)">
                            退回
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
        </mds-card>
        <audit-log :table-data="TimeAudit" />
    </div>
</template>

<script>
import { SQU_API } from '@/api/api';
import { GetStatus } from '@/net/validate';
export default {
    name: 'ManHour',
    components: {
        AuditLog: resolve => {
            require(['@/views/components/AuditLog'], resolve);
        }
    },
    props: {
        isRedact: {
            type: Boolean
        },
        formHeader: {
            type: Object,
            default: function() { return {} }
        }
    },
    data() {
        return {
            timeDate: [],
            timeS: '',
            TimeAudit: []
        };
    },
    computed: {},
    methods: {
        // 提交条数判断
        ManHourRul() {
            let ty = true;
            if (this.timeDate.length <= 0) {
                this.$warningToast('工时计算没有数据');
                ty = false;
                return false;
            }
            return ty;
        },
        // 获取工时列表
        GetTimeList(formHeader, resolve, reject) {
            this.$http(`${SQU_API.SUM_TIME_LIST_API}`, 'POST', {
                factory: formHeader.factory,
                productDate: formHeader.productDate,
                workShop: formHeader.workShop
            }).then(({ data }) => {
                if (data.code === 0) {
                    this.timeDate = data.timeList;
                    this.timeS = GetStatus(data.timeList);
                    if (resolve) {
                        resolve('resolve');
                    }
                } else {
                    if (reject) {
                        reject(data.msg);
                    }
                    this.$errorToast(data.msg);
                }
            });
        },
        // 日志
        GetLog(row) {
            this.$http(`${SQU_API.SUM_LOG_MATERIAL_API}`, 'POST', {
                orderNo: row.orderNo
            }).then(({ data }) => {
                if (data.code === 0) {
                    this.TimeAudit = data.listRecord;
                } else {
                    this.$errorToast(data.msg);
                }
            });
        },
        // 获取工时
        GetTime() {
            this.$http(`${SQU_API.SUM_TIME_API}`, 'POST', this.formHeader).then(({ data }) => {
                if (data.code === 0) {
                    this.GetTimeList(this.formHeader);
                } else {
                    this.$errorToast(data.msg);
                }
            });
        },
        // 修改工时
        UpdateTime(str, resolve, reject, st = false) {
            this.timeDate.forEach((item) => {
                if (item.status) {
                    if (item.status === 'saved') {
                        item.status = str;
                    } else if (item.status === 'noPass' && str === 'submit') {
                        item.status = str;
                    }
                } else {
                    item.status = str;
                }
            });
            this.$http(`${st === false ? SQU_API.SUM_TIME_UPDATE_API : SQU_API.SUM_TIME_SUBMIT_API}`, 'POST', this.timeDate).then(({ data }) => {
                if (data.code === 0) {
                    if (resolve) {
                        resolve('resolve');
                    }
                } else {
                    if (reject) {
                        reject(data.msg);
                    }
                    this.$errorToast(data.msg);
                }
            });
        },
        timeRul() {
            let ty = true;
            this.timeDate.forEach(item => {
                if (item.confActivity2 === '0' || !item.confActivity2) {
                    ty = false;
                    this.$warningToast('机器工时未填写');
                    return false;
                }
            });
            return ty;
        },
        /* eslint-disable no-shadow*/
        // 退回工时
        BackTime(row) {
            this.$http(`${SQU_API.SUM_TIME_BACK_API}`, 'POST', row).then(({ data }) => {
                if (data.code === 0) {
                    this.$notify({
                        title: '成功',
                        message: '退回成功',
                        type: 'success'
                    });
                    this.$http(`${SQU_API.SUM_TIME_API}`, 'POST', {
                        ...this.formHeader,
                        ...{ isActive: '1', id: row.id }
                    }).then(({ data }) => {
                        if (data.code === 0) {
                            this.GetTimeList(this.formHeader);
                        } else {
                            this.$errorToast(data.msg);
                        }
                    });
                } else {
                    this.$errorToast(data.msg);
                }
            });
        }
        /* eslint-enable no-shadow*/
    }
};
</script>

<style scoped></style>
