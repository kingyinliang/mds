<template>
    <div>
        <mds-card :title="'生产入库'" :name="'inVlist'" class="header_main" style="padding: 0;">
            <template slot="titleBtn">
                <div style="float: right;">
                    <el-button type="primary" size="small" :disabled="!isRedact" style="float: right;" @click="AddInDate(InDate)">
                        新增
                    </el-button>
                </div>
            </template>
            <div v-if="order.factoryCode !== '6010'" class="a">
                <div v-if="order.properties && order.properties !== '二合一&礼盒产线'">
                    <el-table v-if="order.properties && order.properties !== '二合一&礼盒产线'" ref="table1" class="newTable" header-row-class-name="tableHead" :data="InDate" :row-class-name="RowDelFlag" border tooltip-effect="dark" style="width: 100%; margin-bottom: 20px;">
                        <el-table-column type="index" width="55" label="序号" fixed />
                        <el-table-column label="白/中/夜班" min-width="120">
                            <template slot-scope="scope">
                                <div class="required">
                                    <i class="reqI">*</i>
                                    <el-select v-model="scope.row.classType" placeholder="请选择" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked')" size="small">
                                        <el-option v-for="(iteam, index) in productShift" :key="index" :label="iteam.value" :value="iteam.code" />
                                    </el-select>
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column label="生产批次" min-width="150">
                            <template slot-scope="scope">
                                <div class="required">
                                    <i class="reqI">*</i>
                                    <el-input v-model="scope.row.batch" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked')" maxlength="10" />
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column label="人工码垛-包材库" min-width="140">
                            <template slot-scope="scope">
                                <el-input v-model="scope.row.manPacking" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked' && scope.row.isZ === '0')" />
                            </template>
                        </el-table-column>
                        <el-table-column label="单位" min-width="60">
                            <template slot-scope="scope">
                                <span>{{ (scope.row.manPackingUnitName = ratio.basicUnitName) }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column v-if="order.workShopName === '包装三车间'" label="自动码垛-包材库" min-width="140">
                            <template slot-scope="scope">
                                <el-input v-model="scope.row.aiPacking" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked' && scope.row.isZ === '0')" />
                            </template>
                        </el-table-column>
                        <el-table-column v-if="order.workShopName === '包装三车间'" label="单位" min-width="60">
                            <template slot-scope="scope">
                                <span>{{ (scope.row.aiPackingUnitName = ratio.basicUnitName) }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="人工码垛-立体库" min-width="140">
                            <template slot-scope="scope">
                                <el-input v-model="scope.row.manSolid" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked' && scope.row.isL === '0')" />
                            </template>
                        </el-table-column>
                        <el-table-column label="单位" min-width="60">
                            <template slot-scope="scope">
                                <span>{{ (scope.row.manSolidUnitName = ratio.productUnitName) }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column v-if="order.workShopName === '包装三车间'" label="自动码垛-立体库" min-width="120">
                            <template slot-scope="scope">
                                <el-input v-model="scope.row.aiSolid" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked' && scope.row.isL === '0')" />
                            </template>
                        </el-table-column>
                        <el-table-column v-if="order.workShopName === '包装三车间'" label="单位" min-width="60">
                            <template slot-scope="scope">
                                <span>{{ (scope.row.aiSolidUnitName = ratio.productUnitName) }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column v-if="order.workShopName !== '包装三车间'" label="自动上架-立体库" min-width="140">
                            <template slot-scope="scope">
                                <el-input v-model="scope.row.aiShelves" type="number" min="0" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked' && scope.row.isL === '0')" />
                            </template>
                        </el-table-column>
                        <el-table-column v-if="order.workShopName !== '包装三车间'" label="单位" min-width="60">
                            <template slot-scope="scope">
                                <span>{{ (scope.row.aiShelvesUnitName = ratio.productUnitName) }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="不良品" min-width="120">
                            <template slot-scope="scope">
                                <el-input v-model="scope.row.bad" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked')" />
                            </template>
                        </el-table-column>
                        <el-table-column label="单位" min-width="60">
                            <template slot-scope="scope">
                                <span>{{ (scope.row.badUnitName = ratio.basicUnitName) }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="样品" min-width="120">
                            <template slot-scope="scope">
                                <el-input v-model="scope.row.sample" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked' && scope.row.isS === '0')" />
                            </template>
                        </el-table-column>
                        <el-table-column label="单位" min-width="60">
                            <template slot-scope="scope">
                                <span>{{ (scope.row.sampleUnitName = ratio.basicUnitName) }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="产出数" min-width="120">
                            <template slot-scope="scope">
                                <span v-if="order.workShopName === '包装三车间'">{{ (scope.row.output = (scope.row.manPacking * 1 + scope.row.aiPacking * 1 + scope.row.manSolid * 1 * (ratio.ratio * 1) + scope.row.aiSolid * 1 * (ratio.ratio * 1) + scope.row.sample * 1).toFixed(2) * 1) }}</span>
                                <span v-else>{{ scope.row.ratio }}{{ (scope.row.output = (scope.row.manPacking * 1 + scope.row.manSolid * 1 * (ratio.ratio * 1) + scope.row.aiShelves * 1 * (ratio.ratio * 1) + scope.row.sample * 1).toFixed(2) * 1) }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="单位" min-width="60">
                            <template slot-scope="scope">
                                <span>{{ (scope.row.outputUnitName = ratio.basicUnitName) }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="备注" min-width="120">
                            <template slot-scope="scope">
                                <el-input v-model="scope.row.remark" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked')" />
                            </template>
                        </el-table-column>
                        <el-table-column fixed="right" label="操作" width="70">
                            <template slot-scope="scope">
                                <el-button
                                    class="delBtn"
                                    type="text"
                                    icon="el-icon-delete"
                                    size="small"
                                    :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked' && scope.row.isL === '0' && scope.row.isZ === '0' && scope.row.isS === '0')"
                                    @click="dellistbomS(scope.row)"
                                >
                                    删除
                                </el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                </div>
                <div v-if="order.properties && order.properties === '二合一&礼盒产线'">
                    <el-table v-if="order.properties && order.properties === '二合一&礼盒产线'" ref="table1" class="newTable" header-row-class-name="tableHead" :data="InDate" :row-class-name="RowDelFlag" border tooltip-effect="dark" style="width: 100%; margin-bottom: 20px;">
                        <el-table-column type="index" width="55" label="序号" fixed />
                        <el-table-column label="白/中/夜班" min-width="120">
                            <template slot-scope="scope">
                                <div class="required">
                                    <i class="reqI">*</i>
                                    <el-select v-model="scope.row.classType" placeholder="请选择" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked')" size="small">
                                        <el-option v-for="(iteam, index) in productShift" :key="index" :label="iteam.value" :value="iteam.code" />
                                    </el-select>
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column label="生产批次" min-width="150">
                            <template slot-scope="scope">
                                <el-input v-if="isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked'" v-model="scope.row.batch" maxlength="10" placeholder="手工录入" size="small" />
                                <el-input v-else v-model="scope.row.batch" placeholder="手工录入" size="small" disabled />
                            </template>
                        </el-table-column>
                        <el-table-column label="人工码垛-立体库" min-width="130">
                            <template slot-scope="scope">
                                <el-input v-model="scope.row.manSolid" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked' && scope.row.isL === '0')" />
                            </template>
                        </el-table-column>
                        <el-table-column label="单位" min-width="50">
                            <template slot-scope="scope">
                                <span>{{ order.workShopName === '组装车间2（礼盒）' ? (scope.row.manSolidUnitName = ratio.basicUnitName) : ratio.productUnitName ? (scope.row.manSolidUnitName = ratio.productUnitName) : (scope.row.manSolidUnitName = ratio.basicUnitName) }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="不良品" min-width="90">
                            <template slot-scope="scope">
                                <el-input v-model="scope.row.bad" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked')" />
                            </template>
                        </el-table-column>
                        <el-table-column label="单位" min-width="50">
                            <template slot-scope="scope">
                                <span>{{ (scope.row.badUnitName = ratio.basicUnitName) }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="样品" min-width="90">
                            <template slot-scope="scope">
                                <el-input v-model="scope.row.sample" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked' && scope.row.isS === '0')" />
                            </template>
                        </el-table-column>
                        <el-table-column label="单位" min-width="50">
                            <template slot-scope="scope">
                                <span>{{ (scope.row.sampleUnitName = ratio.basicUnitName) }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="产出数" min-width="90">
                            <template slot-scope="scope">
                                {{ order.workShopName === '组装车间2（礼盒）' ? (scope.row.output = scope.row.manSolid * 1 + scope.row.sample * 1) : (scope.row.output = (scope.row.manSolid * 1 * (ratio.ratio * 1) + scope.row.sample * 1).toFixed(2) * 1) }}
                            </template>
                        </el-table-column>
                        <el-table-column label="单位" min-width="50">
                            <template slot-scope="scope">
                                <span>{{ (scope.row.outputUnitName = ratio.basicUnitName) }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="主产品批次" min-width="120">
                            <template slot-scope="scope">
                                <el-input v-model="scope.row.mainBatch" maxlength="10" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked')" />
                            </template>
                        </el-table-column>
                        <el-table-column label="赠品批次" min-width="120">
                            <template slot-scope="scope">
                                <el-input v-model="scope.row.attachBatch" maxlength="10" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked')" />
                            </template>
                        </el-table-column>
                        <el-table-column label="备注" min-width="120">
                            <template slot-scope="scope">
                                <el-input v-model="scope.row.remark" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked')" />
                            </template>
                        </el-table-column>
                        <el-table-column fixed="right" label="操作" width="70">
                            <template slot-scope="scope">
                                <el-button
                                    class="delBtn"
                                    type="text"
                                    icon="el-icon-delete"
                                    size="small"
                                    :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked' && scope.row.isL === '0' && scope.row.isZ === '0' && scope.row.isS === '0')"
                                    @click="dellistbomS(scope.row)"
                                >
                                    删除
                                </el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                </div>
            </div>
            <div v-if="order.factoryCode === '6010'" class="b">
                <el-table ref="table1" class="newTable" header-row-class-name="tableHead" :data="InDate" :row-class-name="RowDelFlag" border tooltip-effect="dark" style="width: 100%; margin-bottom: 20px;">
                    <el-table-column type="index" width="55" label="序号" fixed />
                    <el-table-column label="白/中/夜班" min-width="120">
                        <template slot-scope="scope">
                            <div class="required">
                                <em class="reqI">*</em>
                                <el-select v-model="scope.row.classType" placeholder="请选择" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked')" size="small">
                                    <el-option v-for="(iteam, index) in productShift" :key="index" :label="iteam.value" :value="iteam.code" />
                                </el-select>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column label="生产批次" min-width="150">
                        <template slot-scope="scope">
                            <el-input v-if="isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked'" v-model="scope.row.batch" maxlength="10" placeholder="手工录入" size="small" />
                            <el-input v-else v-model="scope.row.batch" placeholder="手工录入" size="small" disabled />
                        </template>
                    </el-table-column>
                    <el-table-column label="正常品" min-width="140">
                        <template slot-scope="scope">
                            <el-input v-model="scope.row.aiShelves" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked' && scope.row.isL === '0')" />
                        </template>
                    </el-table-column>
                    <el-table-column label="单位" min-width="90">
                        <template slot-scope="scope">
                            <el-select v-model="scope.row.aiShelvesUnit" placeholder="请选择" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked')" size="small">
                                <el-option v-if="ratio.productUnit" :label="ratio.productUnitName" :value="ratio.productUnit" />
                                <el-option v-if="ratio.basicUnit" :label="ratio.basicUnitName" :value="ratio.basicUnit" />
                            </el-select>
                        </template>
                    </el-table-column>
                    <el-table-column label="供应商待买" min-width="140">
                        <template slot-scope="scope">
                            <el-input v-model="scope.row.manSolid" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked' && scope.row.isL === '0')" />
                        </template>
                    </el-table-column>
                    <el-table-column label="单位" min-width="90">
                        <template slot-scope="scope">
                            <span>{{ (scope.row.manSolidUnitName = ratio.basicUnitName) }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="需整理品" min-width="140">
                        <template slot-scope="scope">
                            <el-input v-model="scope.row.manPacking" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked' && scope.row.isZ === '0')" />
                        </template>
                    </el-table-column>
                    <el-table-column label="单位" min-width="90">
                        <template slot-scope="scope">
                            <span>{{ (scope.row.manPackingUnitName = ratio.basicUnitName) }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="不良品" min-width="120">
                        <template slot-scope="scope">
                            <el-input v-model="scope.row.bad" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked')" />
                        </template>
                    </el-table-column>
                    <el-table-column label="单位" min-width="90">
                        <template slot-scope="scope">
                            <span>{{ (scope.row.badUnitName = ratio.basicUnitName) }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="样品" min-width="120">
                        <template slot-scope="scope">
                            <el-input v-model="scope.row.sample" placeholder="手工录入" size="small" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked' && scope.row.isS === '0')" />
                        </template>
                    </el-table-column>
                    <el-table-column label="单位" min-width="90">
                        <template slot-scope="scope">
                            <span>{{ (scope.row.sampleUnitName = ratio.basicUnitName) }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="产出数" min-width="120">
                        <template slot-scope="scope">
                            <span>{{
                                (scope.row.output =
                                    (
                                        scope.row.aiShelves * 1 * (scope.row.aiShelvesUnit === ratio.productUnit ? ratio.ratio * 1 : 1) +
                                        scope.row.manSolid * 1 * (scope.row.manSolidUnit === ratio.productUnit ? ratio.ratio * 1 : 1) +
                                        scope.row.manPacking * 1 * (scope.row.manPackingUnit === ratio.productUnit ? ratio.ratio * 1 : 1) +
                                        scope.row.sample * 1 * (scope.row.sampleUnit === ratio.productUnit ? ratio.ratio * 1 : 1)
                                    ).toFixed(2) * 1)
                            }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="单位" min-width="60">
                        <template slot-scope="scope">
                            <span>{{ (scope.row.outputUnitName = ratio.basicUnitName) }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="备注" min-width="120">
                        <template slot-scope="scope">
                            <el-input v-model="scope.row.remark" :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked')" placeholder="手工录入" size="small" />
                        </template>
                    </el-table-column>
                    <el-table-column fixed="right" label="操作" width="70">
                        <template slot-scope="scope">
                            <el-button
                                class="delBtn"
                                type="text"
                                icon="el-icon-delete"
                                size="small"
                                :disabled="!(isRedact && scope.row.status !== 'submit' && scope.row.status !== 'checked' && scope.row.isL === '0' && scope.row.isZ === '0' && scope.row.isS === '0')"
                                @click="dellistbomS(scope.row)"
                            >
                                删除
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </div>
            <div>
                <p style=" font-size: 14px;">
                    产出数合计：{{ countOutputNum }}
                </p>
            </div>
        </mds-card>
        <div v-if="order.properties !== '二合一&礼盒产线' && order.workShopName !== '包装三车间' && order.factoryCode !== '6010'">
            <mds-card :title="'机维组数量确认'" :name="'inVlist'" class="header_main" style="padding: 0;">
                <template slot="titleBtn">
                    <div style="float: right;">
                        <el-button type="primary" size="small" style="float: right;" @click="GetMaintain()">
                            刷新
                        </el-button>
                    </div>
                </template>
                <el-table ref="table1" class="newTable" header-row-class-name="tableHead" :data="InVlist" border tooltip-effect="dark" style="width: 100%; margin-bottom: 20px;">
                    <el-table-column type="index" width="55" label="序号" fixed />
                    <el-table-column prop="orderNo" label="生产订单号" min-width="120" />
                    <el-table-column prop="batch" label="生产批次" min-width="120" />
                    <el-table-column prop="aiShelves" label="自动上架数-立体库" min-width="120" />
                    <el-table-column prop="aiShelvesUnitName" label="单位" min-width="60" />
                    <el-table-column prop="jwzAcount" label="机维组确认数" min-width="120" />
                    <el-table-column prop="differentUnitName" label="单位" min-width="60" />
                    <el-table-column prop="orgnDifferent" label="原差异数量" min-width="120" />
                    <el-table-column prop="differentUnitName" label="单位" min-width="60" />
                    <el-table-column prop="differentInfo" label="差异说明" min-width="120" />
                    <el-table-column prop="jwzMan" label="机维组确认人" />
                </el-table>
            </mds-card>
        </div>
        <audit-log :table-data="InAudit" />
    </div>
</template>

<script>
import { PACKAGING_API, SYSTEMSETUP_API } from '@/api/api';
import { GetStatus, accAdd } from '@/net/validate';
export default {
    name: 'InStorage',
    components: {
        AuditLog: resolve => {
            require(['@/views/components/AuditLog'], resolve);
        }
    },
    props: {
        isRedact: {
            type: Boolean
        },
        order: {
            type: Object,
            default: function() { return {} }
        },
        ratio: {
            type: Object,
            default: function() { return {} }
        }
    },
    data() {
        return {
            Instatus: '',
            productShift: [],
            InDate: [],
            InVlist: [],
            InAudit: []
        };
    },
    computed: {
        countOutputNum: function() {
            let num = 0;
            this.InDate.forEach(item => {
                num = num + (item.delFlag === '0' ? item.output : 0);
            });
            return num;
        }
    },
    mounted() {
        // this.GetProductShift()
    },
    methods: {
        // 修改生产入库
        UpdateIn(id, str, resolve) {
            if (this.InDate.length > 0) {
                let types = '';
                if (this.order.properties === '二合一&礼盒产线') {
                    types = 'twoAndOne';
                } else if (this.order.workShopName === '包装三车间') {
                    types = 'isPkgThree';
                }
                this.InDate.forEach(item => {
                    this.SetUnit(item);
                    item.orderId = id;
                    if (item.status) {
                        if (item.status === 'saved') {
                            item.status = str;
                        } else if (item.status === 'noPass' && str === 'submit') {
                            item.status = str;
                        }
                    } else {
                        item.status = str;
                    }
                    item.isPkgThree = types;
                    // item.badUnit = this.ratio.basicUnit
                    // item.sampleUnit = this.ratio.basicUnit
                    // item.outputUnit = this.ratio.basicUnit
                    // item.manPackingUnit = this.ratio.basicUnit
                    // item.aiPackingUnit = this.ratio.basicUnit
                    // item.aiSolidUnit = this.ratio.productUnit
                    // item.aiShelvesUnit = this.ratio.productUnit
                    // this.order.workShopName === '组装车间2（礼盒）' ? (item.manSolidUnit = this.ratio.basicUnit) : (this.ratio.productUnit ? item.manSolidUnit = this.ratio.productUnit : item.manSolidUnit = this.ratio.basicUnit)
                });
                this.$http(`${PACKAGING_API.PKGINUPDATE_API}`, 'POST', this.InDate).then(({ data }) => {
                    if (data.code !== 0) {
                        this.$notify.error({
                            title: '错误',
                            message: '生产入库' + data.msg
                        });
                    }
                    if (resolve) {
                        resolve('resolve');
                    }
                });
            } else if (resolve) {
                    resolve('resolve');
                }
        },
        // 入库单位重新赋值
        SetUnit(item) {
            if (this.order.factoryCode === '6010') {
                item.manPackingUnit = this.ratio.basicUnit;
                item.manPackingUnitName = this.ratio.basicUnitName;
                item.aiPackingUnit = this.ratio.basicUnit;
                item.aiPackingUnitName = this.ratio.basicUnitName;
                item.aiSolidUnit = this.ratio.basicUnit;
                item.aiSolidUnitName = this.ratio.basicUnitName;
                item.manSolidUnit = this.ratio.basicUnit;
                item.manSolidUnitName = this.ratio.basicUnitName;
                item.badUnit = this.ratio.basicUnit;
                item.badUnitName = this.ratio.basicUnitName;
                item.sampleUnit = this.ratio.basicUnit;
                item.sampleUnitName = this.ratio.basicUnitName;
                item.outputUnit = this.ratio.basicUnit;
                item.outputUnitName = this.ratio.basicUnitName;
            } else {
                item.manPackingUnit = this.ratio.basicUnit;
                item.manPackingUnitName = this.ratio.basicUnitName;
                item.aiPackingUnit = this.ratio.basicUnit;
                item.aiPackingUnitName = this.ratio.basicUnitName;
                item.aiShelvesUnit = this.ratio.productUnit;
                item.aiShelvesUnitName = this.ratio.productUnitName;
                item.aiSolidUnit = this.ratio.productUnit;
                item.aiSolidUnitName = this.ratio.productUnitName;
                item.manSolidUnit = this.order.properties && this.order.properties !== '二合一&礼盒产线' ? this.ratio.productUnit : this.order.workShopName === '组装车间2（礼盒）' ? this.ratio.basicUnit : this.ratio.productUnit ? this.ratio.productUnit : this.ratio.basicUnit;
                item.manSolidUnitName = this.order.properties && this.order.properties !== '二合一&礼盒产线' ? this.ratio.productUnitName : this.order.workShopName === '组装车间2（礼盒）' ? this.ratio.basicUnitName : this.ratio.productUnitName ? this.ratio.productUnitName : this.ratio.basicUnitName;
                item.badUnit = this.ratio.basicUnit;
                item.badUnitName = this.ratio.basicUnitName;
                item.sampleUnit = this.ratio.basicUnit;
                item.sampleUnitName = this.ratio.basicUnitName;
                item.outputUnit = this.ratio.basicUnit;
                item.outputUnitName = this.ratio.basicUnitName;
            }
        },
        isSt(item) {
            if ((item.manSolid && item.manSolid !== '0') || (item.aiSolid && item.aiSolid !== '0') || (item.aiShelves && item.aiShelves !== '0')) {
                if (item.isL === '0') {
                    item.isL = '1';
                }
            }
            if ((item.manPacking && item.manPacking !== '0') || (item.aiPacking && item.aiPacking !== '0')) {
                if (item.isZ === '0') {
                    item.isZ = '1';
                }
            }
            if (item.sample && item.sample !== '0') {
                if (item.isS === '0') {
                    item.isS = '1';
                }
            }
        },
        // 入库提交
        submitIn(id, str, resolve, reject) {
            let types = '';
            if (this.order.properties === '二合一&礼盒产线') {
                types = 'twoAndOne';
            } else if (this.order.workShopName === '包装三车间') {
                types = 'isPkgThree';
            }
            this.InDate.forEach(item => {
                this.SetUnit(item);
                this.isSt(item);
                item.orderId = id;
                if (item.status) {
                    if (item.status === 'saved') {
                        item.status = str;
                    } else if (item.status === 'noPass' && str === 'submit') {
                        item.status = str;
                    }
                } else {
                    item.status = str;
                }
                item.isPkgThree = types;
            });
            this.$http(`${PACKAGING_API.PKGSAVEFORMIN_API}`, 'POST', this.InDate).then(({ data }) => {
                if (data.code === 0) {
                    if (resolve) {
                        resolve('resolve');
                    }
                } else {
                    if (reject) {
                        reject('提交失败');
                    }
                    this.$errorToast(data.msg);
                }
            });
        },
        // 入库校验
        inrul() {
            let ty = true;
            this.instatus = 0;
            const obj = {};
            if (this.InDate.filter(item => item.delFlag !== '1').length === 0) {
                ty = false;
                this.$warningToast('生产入库没有数据');
                return false;
            }
            this.InDate.forEach(item => {
                if (item.delFlag !== '1') {
                    item.aiShelves = String(item.aiShelves);
                    // if (!this.UnitRul(item)) {
                    //   ty = false
                    //   this.$message.error('生产入库单位未获取')
                    //   return false
                    // }
                    if (!item.output) {
                        ty = false;
                        this.$warningToast('生产入库产出数不能为空或0');
                        return false;
                    }
                    if (!item.classType) {
                        ty = false;
                        this.$warningToast('生产入库班次不能为空');
                        return false;
                    }
                    if (item.batch) {
                        // if (item.batch.length !== 10) {
                        //   ty = false
                        //   this.$warningToast('生产入库请录入10位批次号')
                        //   return false
                        // }
                    } else {
                        ty = false;
                        this.$warningToast('生产入库批次项未填');
                        return false;
                    }
                    if (item.aiShelves !== '' && item.aiShelves !== '0') {
                        this.instatus = 1;
                        if (obj[item.batch]) {
                            obj[item.batch] = Number(obj[item.batch]) + Number(item.aiShelves);
                        } else {
                            obj[item.batch] = Number(item.aiShelves);
                        }
                    }
                }
            });
            if (this.order.properties !== '二合一&礼盒产线' && this.order.workShopName !== '包装三车间' && this.order.factoryCode !== '6010') {
                Object.keys(obj).forEach(key => {
                    let tmp = true;
                    this.InVlist.forEach(item => {
                        if (item.batch === key && item.aiShelves === obj[key]) {
                            tmp = false;
                        }
                    });
                    if (tmp) {
                        ty = false;
                        this.$warningToast('机维组未确认，请保存后等待机维组确认后提交');
                        return false;
                    }
                });
            }
            // 批次 确认数校验
            if (this.order.properties !== '二合一&礼盒产线' && this.order.workShopName !== '包装三车间' && this.order.factoryCode !== '6010') {
                // 数据整理
                const InDateArray = [];
                this.InDate.filter(items => items.delFlag === '0').map(item => {
                    const InDateSole = InDateArray.find(x => x.batch === item.batch);
                    if (InDateSole) {
                        InDateSole.aiShelves = accAdd(InDateSole.aiShelves, item.aiShelves);
                    } else {
                        InDateArray.push({
                            batch: item.batch,
                            aiShelves: Number(item.aiShelves)
                        });
                    }
                })
                if (this.InVlist.length !== InDateArray.filter(x => x.aiShelves !== 0).length) {
                    ty = false;
                    this.$warningToast('生产入库批次不一致，请确认');
                    return false;
                }
                // const jiaoji = this.InVlist.filter(x => InDateArray.find(y => (x.batch === y.batch && Number(x.aiShelves) === y.aiShelves)))
                // console.log(jiaoji);
                // if (jiaoji.length !== this.InVlist.length) {
                //     ty = false;
                //     this.$warningToast('生产入库机维组确认数不一致，请确认');
                //     return false;
                // }
                InDateArray.map((item) => {
                    if (this.InVlist.find(inItem => inItem.batch === item.batch) && this.InVlist.find(inItem => inItem.batch === item.batch).jwzAcount !== item.aiShelves) {
                        ty = false;
                        this.$warningToast('生产入库机维组确认数不一致，请确认');
                        return false;
                    }
                })
            }
            return ty;
            // return false;
        },
        // 单位校验
        UnitRul(item) {
            let ty = true;
            if (this.order.factoryCode === '6010') {
                if (item.manPackingUnit && item.aiPackingUnit && item.aiShelvesUnit && item.aiSolidUnit && item.manSolidUnit && item.badUnit && item.sampleUnit && item.outputUnit) {
                    //
                } else {
                    ty = false;
                }
            } else if (item.manPackingUnit && item.aiPackingUnit && item.badUnit && item.sampleUnit && item.outputUnit) {
                    if (this.order.properties && this.order.properties !== '二合一&礼盒产线') {
                        //
                    } else if (item.manSolidUnit) {
                        //
                    } else {
                        ty = false;
                    }
                } else {
                    ty = false;
                }
            return ty;
        },
        // 获取生产班次
        GetProductShift(factory) {
            this.$http(`${SYSTEMSETUP_API.PARAMETERLIST_API}`, 'POST', {
                factory: factory,
                type: 'product_shift'
            }).then(({ data }) => {
                if (data.code === 0) {
                    this.productShift = data.dicList;
                } else {
                    this.$errorToast(data.msg);
                }
            });
        },
        // 获取包装车间生产入库列表
        Getpkgin(order) {
            this.$http(`${PACKAGING_API.PKGINLIST_API}`, 'POST', {
                orderId: order.orderId,
                isPkgThree: order.properties === '二合一&礼盒产线' ? 'twoAndOne' : order.workShopName === '包装三车间' ? 'isPkgThree' : ''
            }).then(({ data }) => {
                if (data.code === 0) {
                    this.InDate = data.plist;
                    this.InVlist = data.vlist;
                    this.InAudit = data.vrlist;
                    if (this.InDate.length === 0) {
                        this.AddInDate(this.InDate);
                    }
                    if (order.orderStatus !== '已同步') {
                        if (order.orderStatus === 'checked') {
                            this.Instatus = 'checked';
                        } else if (order.orderStatus === 'submit') {
                            this.Instatus = 'submit';
                        } else if (order.orderStatus === 'saved') {
                            this.Instatus = 'saved';
                        }
                    }
                    this.Instatus = GetStatus(this.InDate);
                    this.$emit('GetinstorageState', this.Instatus);
                } else {
                    this.$errorToast(data.msg);
                }
            });
        },
        // 机维组刷新
        GetMaintain() {
            this.$http(`${PACKAGING_API.PKGINLIST_API}`, 'POST', {
                orderId: this.order.orderId,
                isPkgThree: this.order.properties === '二合一&礼盒产线' ? 'twoAndOne' : this.order.workShopName === '包装三车间' ? 'isPkgThree' : ''
            }).then(({ data }) => {
                if (data.code === 0) {
                    this.InVlist = data.vlist;
                    this.$notify({
                        title: '成功',
                        message: '刷新成功',
                        type: 'success'
                    });
                } else {
                    this.$errorToast(data.msg);
                }
            });
        },
        // 新增入库
        AddInDate(form) {
            if (this.order.factoryCode === '6010') {
                form.push({
                    isL: '0',
                    isZ: '0',
                    isS: '0',
                    status: '',
                    isPkgThree: '',
                    orderId: '',
                    classType: '',
                    batch: '',
                    manPacking: '',
                    manPackingUnit: this.ratio.basicUnit,
                    manPackingUnitName: this.ratio.basicUnitName,
                    aiPacking: '',
                    aiPackingUnit: this.ratio.basicUnit,
                    aiPackingUnitName: this.ratio.basicUnitName,
                    aiShelves: '',
                    aiShelvesUnit: this.ratio.productUnit ? this.ratio.productUnit : this.ratio.basicUnit,
                    aiShelvesUnitName: this.ratio.productUnitName ? this.ratio.productUnitName : this.ratio.basicUnitName,
                    aiSolid: '',
                    aiSolidUnit: this.ratio.basicUnit,
                    aiSolidUnitName: this.ratio.basicUnitName,
                    manSolid: '',
                    manSolidUnit: this.ratio.basicUnit,
                    manSolidUnitName: this.ratio.basicUnitName,
                    bad: '',
                    badUnit: this.ratio.basicUnit,
                    badUnitName: this.ratio.basicUnitName,
                    sample: 0,
                    sampleUnit: this.ratio.basicUnit,
                    sampleUnitName: this.ratio.basicUnitName,
                    output: '',
                    outputUnit: this.ratio.basicUnit,
                    outputUnitName: this.ratio.basicUnitName,
                    mainBatch: '',
                    attachBatch: '',
                    delFlag: '0'
                });
            } else {
                form.push({
                    isL: '0',
                    isZ: '0',
                    isS: '0',
                    status: '',
                    isPkgThree: '',
                    orderId: '',
                    classType: '',
                    batch: '',
                    manPacking: '',
                    manPackingUnit: this.ratio.basicUnit,
                    manPackingUnitName: this.ratio.basicUnitName,
                    aiPacking: '',
                    aiPackingUnit: this.ratio.basicUnit,
                    aiPackingUnitName: this.ratio.basicUnitName,
                    aiShelves: '',
                    aiShelvesUnit: this.ratio.productUnit,
                    aiShelvesUnitName: this.ratio.productUnitName,
                    aiSolid: '',
                    aiSolidUnit: this.ratio.productUnit,
                    aiSolidUnitName: this.ratio.productUnitName,
                    manSolid: '',
                    manSolidUnit: this.order.properties && this.order.properties !== '二合一&礼盒产线' ? this.ratio.productUnit : this.order.workShopName === '组装车间2（礼盒）' ? this.ratio.basicUnit : this.ratio.productUnit ? this.ratio.productUnit : this.ratio.basicUnit,
                    manSolidUnitName: this.order.properties && this.order.properties !== '二合一&礼盒产线' ? this.ratio.productUnitName : this.order.workShopName === '组装车间2（礼盒）' ? this.ratio.basicUnitName : this.ratio.productUnitName ? this.ratio.productUnitName : this.ratio.basicUnitName,
                    bad: '',
                    badUnit: this.ratio.basicUnit,
                    badUnitName: this.ratio.basicUnitName,
                    sample: 0,
                    sampleUnit: this.ratio.basicUnit,
                    sampleUnitName: this.ratio.basicUnitName,
                    output: '',
                    outputUnit: this.ratio.basicUnit,
                    outputUnitName: this.ratio.basicUnitName,
                    mainBatch: '',
                    attachBatch: '',
                    delFlag: '0'
                });
            }
        },
        // 删除
        dellistbomS(row) {
            this.$confirm('是否删除?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                row.delFlag = '1';
            }).catch(() => {
                // this.$infoToast('已取消删除');
            });
        },
        //  RowDelFlag
        RowDelFlag({ row }) {
            if (row.delFlag === '1') {
                return 'rowDel';
            }
                return '';

        }
    }
};
</script>

<style scoped></style>
