<template>
    <div class="header_main">
        <el-card class="searchCard ferCard">
            <el-form :inline="true" :model="formHeader" size="small" label-width="70px" class="multi_row">
                <el-form-item label="生产工厂：">
                    <el-select v-model="formHeader.factory" placeholder="请选择" style="width: 140px;">
                        <el-option label="请选择" value="" />
                        <el-option v-for="(item, index) in factory" :key="index" :label="item.deptName" :value="item.deptId" />
                    </el-select>
                </el-form-item>
                <el-form-item label="生产车间：">
                    <el-select v-model="formHeader.workShop" placeholder="请选择" style="width: 140px;">
                        <el-option label="请选择" value="" />
                        <el-option v-for="(item, index) in workshop" :key="index" :label="item.deptName" :value="item.deptId" />
                    </el-select>
                </el-form-item>
                <el-form-item label="罐类型：">
                    <el-select v-model="formHeader.potType" placeholder="请选择" style="width: 140px;" @change="ChangeSearch()">
                        <el-option label="请选择" value="" />
                        <el-option v-for="(sole, index) in potTypeList" :key="index" :value="sole.value" :label="sole.name" />
                    </el-select>
                </el-form-item>
                <el-form-item label="罐号：" label-width="50px">
                    <el-select v-model="formHeader.potNo" placeholder="请选择" multiple filterable allow-create default-first-op style="width: 140px;" @change="ChangeSearch()">
                        <el-option v-for="(sole, index) in guanList" :key="index" :value="sole.holderNo" :label="sole.holderName" />
                    </el-select>
                </el-form-item>
                <el-form-item label="类别：" label-width="50px">
                    <el-select v-model="formHeader.type" placeholder="请选择" style="width: 140px;" @change="ChangeSearch()">
                        <el-option label="请选择" value="" />
                        <el-option v-for="(item, index) in typeList" :key="index" :label="item.halfType" :value="item.halfType" />
                    </el-select>
                </el-form-item>
                <el-form-item label="状态：">
                    <el-select v-model="formHeader.status" placeholder="请选择" style="width: 140px;" @change="ChangeSearch()">
                        <el-option label="请选择" value="" />
                        <el-option v-for="(item, index) in holderStatusList" :key="index" :label="item.value" :value="item.code" />
                    </el-select>
                </el-form-item>
                <el-form-item label="待转储：">
                    <el-select v-model="formHeader.dump" placeholder="请选择" style="width: 140px;" @change="ChangeSearch()">
                        <el-option label="请选择" value="" />
                        <el-option v-for="(item, index) in dumpList" :key="index" :label="item.name" :value="item.value" />
                    </el-select>
                </el-form-item>
                <el-form-item label="标识：">
                    <el-select v-model="formHeader.isF" placeholder="请选择" style="width: 140px;">
                        <el-option label="请选择" value="" />
                        <el-option v-for="(item, index) in isFList" :key="index" :label="item.name" :value="item.value" />
                    </el-select>
                </el-form-item>
                <el-form-item style="float: right;">
                    <el-button v-if="isAuth('juice:pot:List')" type="primary" size="small" style="float: right;" @click="GetDataList(true)">
                        查询
                    </el-button>
                </el-form-item>
            </el-form>
        </el-card>
        <mds-card v-show="fastS" title="原汁情况总览" name="potTotal" style="margin-top: 10px;">
            <div class="sumbox">
                <div class="topBox clearfix">
                    <div v-for="(item, index) in topBox" :key="index" class="clearfix" style="float: left;">
                        <div class="topBox_boxItem" @click="topClick(item)">
                            <div class="topBox_boxItem_bar">
                                <div class="topBox_boxItem_bar_box" :style="{ background: `linear-gradient(to right,${item.startColor} 0%,${item.startColor} 10%,${item.endColor})` }" />
                            </div>
                            <p class="topBox_boxItem_tit">
                                {{ item.ptext }}
                            </p>
                            <p class="topBox_boxItem_detail">
                                总计: <span>{{ item.num }}</span> 罐
                            </p>
                            <div v-if="item.content !== 0" class="topBox_boxItem_popover">
                                <p v-for="(i, ins) in Object.keys(item.content)" :key="ins">
                                    <em v-if="i != ''" class="dot" :style="{ background: ins === 0 ? '#1890FF' : ins === 1 ? '#FFBF00' : '#1890FF' }" />{{ i }} <span v-if="i != ''" style="float: right;">{{ item.content[i] }}方</span>
                                </p>
                                <em class="topBox_boxItem_popover_ar" />
                            </div>
                        </div>
                        <div v-if="item.color" class="topBox_circle" :style="{ background: item.color }">
                            {{ item.text }}
                        </div>
                    </div>
                </div>
            </div>
        </mds-card>
        <mds-card v-show="fastS" title="原汁罐列表" name="potTotal" :pack-up="false">
            <template slot="titleBtn">
                <div style="float: right; height: 32px; margin-bottom: 10px; line-height: 32px;">
                    <em v-if="isAuth('juice:pot:juiceStockItem')"><a href="#/DataEntry-Juice-Pot-summary" style="color: #487bff; font-size: 14px;">原汁库存情况>></a></em>
                </div>
            </template>
            <div>
                <el-row class="potList" :gutter="10" style="min-height: 150px;">
                    <el-col v-for="(item, index) in dataList" :key="index" :span="4">
                        <div class="box">
                            <div class="box_title">
                                {{ item.HOLDER_NO }}-{{ item.HOLDER_STATUS === '6' ? '空罐' : item.HOLDER_STATUS === '7' ? '入料中' : item.HOLDER_STATUS === '8' ? '沉淀中' : item.HOLDER_STATUS === '9' ? '领用中' : item.HOLDER_STATUS === '10' ? '待清洗' : '' }}
                                <a v-if="isAuth('juice:pot:juiceItem')" @click="godetails(item)">详情>></a>
                            </div>
                            <div class="box_content">
                                <img v-if="item.IS_F === '1'" src="@/assets/img/F0.png" alt="" style="position: absolute; top: 0; left: 10px; z-index: 101;">
                                <img v-if="item.isRd === 1" src="@/assets/img/RD.png" alt="" style="position: absolute; top: 28px; left: 10px; z-index: 101;">
                                <img v-if="item.IS_F === '2'" src="@/assets/img/jbs.png" alt="" style="position: absolute; top: 56px; left: 10px; z-index: 101;">
                                <div class="box_content_itemPot">
                                    <div class="pot_border">
                                        <div class="pot" />
                                        <div class="pot_water">
                                            <div
                                                class="pot_water_sole"
                                                :style="{'height': (item.HOLDER_STATUS === '6' ? 0 : item.AMOUNT ? ((item.AMOUNT * 1000) / item.HOLDER_HOLD) * 100 : 0) + '%', 'background': item.potColor}"
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div class="box_content_itemButton buttonCss">
                                    <el-button type="primary" size="small" @click="TransferProp(item)">
                                        转储
                                    </el-button>
                                    <el-button type="primary" size="small" @click="JuiceJudgeProp(item)">
                                        判定
                                    </el-button>
                                    <el-button type="primary" size="small" @click="ClearProp(item)">
                                        清洗
                                    </el-button>
                                    <el-button type="primary" size="small" @click="BringOutProp(item)">
                                        调整
                                    </el-button>
                                </div>
                            </div>
                            <div class="box_bottom">
                                <div v-if="item.HOLDER_STATUS !== '6' && item.HOLDER_STATUS !== '10'">
                                    <div class="box_bottom_sole">
                                        {{ item.TYPE }}
                                    </div>
                                    <div class="box_bottom_sole">
                                        {{ item.BATCH }}
                                    </div>
                                    <div class="box_bottom_sole">
                                        {{ item.days }}天
                                    </div>
                                    <div class="box_bottom_sole">
                                        {{ item.AMOUNT }}方
                                    </div>
                                </div>
                                <div v-else>
                                    <div class="box_bottom_sole colorGray">
                                        暂无数据
                                    </div>
                                    <div class="box_bottom_sole colorGray">
                                        暂无数据
                                    </div>
                                    <div class="box_bottom_sole colorGray">
                                        暂无数据
                                    </div>
                                    <div class="box_bottom_sole colorGray">
                                        暂无数据
                                    </div>
                                </div>
                            </div>
                        </div>
                    </el-col>
                </el-row>
                <el-row>
                    <el-pagination :current-page.sync="pages.currentPage" :page-size="42" layout="total, prev, pager, next" :total="pages.total" @size-change="handleSizeChange" @current-change="handleCurrentChange" />
                </el-row>
            </div>
        </mds-card>
        <el-dialog :visible.sync="TransferDialogTableVisible" :close-on-click-modal="false" width="500px" custom-class="dialog__class">
            <div slot="title">
                转储
            </div>
            <div>
                <el-form ref="Transferstar" size="small" :model="formTransfer" :rules="Transferulestar" label-width="150px">
                    <el-form-item label="领用罐号：">
                        {{ formTransfer.holderName }}
                    </el-form-item>
                    <el-form-item label="物料：">
                        {{ formTransfer.materialName }} {{ formTransfer.materialCode }}
                    </el-form-item>
                    <el-form-item label="类别：">
                        {{ formTransfer.type }}
                    </el-form-item>
                    <el-form-item label="批次：">
                        {{ formTransfer.batch }}
                    </el-form-item>
                    <el-form-item label="领用量（L）：" prop="receiveAmount">
                        <el-input v-model="formTransfer.receiveAmount" type="number" style="width: 200px;" placeholder="大于0" @mousewheel.native.prevent />
                    </el-form-item>
                    <el-form-item label="打入罐类别：" prop="inHolderType">
                        <el-select v-model="formTransfer.inHolderType" placeholder="请选择" clearable style="width: 200px;">
                            <el-option label="请选择" value="" />
                            <el-option v-for="(sole, index) in potTypeList" :key="index" :value="sole.value" :label="sole.name" />
                        </el-select>
                    </el-form-item>
                    <el-form-item>
                        <el-radio v-model="formTransfer.isF" label="1">
                            F0标识
                        </el-radio>
                        <el-radio v-model="formTransfer.isF" label="2">
                            原汁JBS
                        </el-radio>
                    </el-form-item>
                    <el-form-item label="打入罐号：" prop="inHolderId">
                        <el-select v-model="formTransfer.inHolderId" style="width: 200px;">
                            <el-option v-for="(item, index) in thrwHolderList" :key="index" :value="item.HOLDER_ID" :label="item.HOLDER_NAME" />
                        </el-select>
                    </el-form-item>
                    <el-form-item label="物料：">
                        {{ formTransfer.materialName }} {{ formTransfer.materialCode }}
                    </el-form-item>
                    <el-form-item label="类别：">
                        {{ formTransfer.type }}
                    </el-form-item>
                    <el-form-item label="打入批次：" prop="inBatch">
                        <el-input v-model="formTransfer.inBatch" maxlength="10" style="width: 200px;" />
                    </el-form-item>
                    <el-form-item label="是否满灌：">
                        <el-select v-model="formTransfer.isFull" filterable style="width: 200px;">
                            <el-option v-for="(item, index) in isFullList" :key="index" :value="item.value" :label="item.name" />
                        </el-select>
                    </el-form-item>
                    <el-form-item label="满灌时间：">
                        <el-date-picker v-model="formTransfer.fullDate" type="datetime" value-format="yyyy-MM-dd HH:mm" format="yyyy-MM-dd HH:mm" placeholder="请选择" style="width: 200px;" />
                    </el-form-item>
                </el-form>
            </div>
            <span slot="footer" class="dialog-footer">
                <el-button size="small" @click="TransferDialogTableVisible = false">取消</el-button>
                <el-button type="primary" size="small" @click="FormTransferSave('Transferstar')">确定</el-button>
            </span>
        </el-dialog>
        <el-dialog :visible.sync="AddDialogTableVisible" :close-on-click-modal="false" width="500px" custom-class="dialog__class">
            <div slot="title">
                HD
            </div>
            <div>
                <el-form ref="Addstar" size="small" :model="formAdd" :rules="Addrulestar" label-width="150px">
                    <el-form-item label="领用罐号：">
                        {{ formAdd.holderName }}
                    </el-form-item>
                    <el-form-item label="物料：">
                        {{ formAdd.materialName }} {{ formAdd.materialCode }}
                    </el-form-item>
                    <el-form-item label="类别：">
                        {{ formAdd.type }}
                    </el-form-item>
                    <el-form-item label="批次：">
                        {{ formAdd.batch }}
                    </el-form-item>
                    <el-form-item label="领用量（L）：" prop="amount">
                        <el-input v-model="formAdd.amount" style="width: 200px;" />
                    </el-form-item>
                    <el-form-item label="打入罐类别：" prop="inHolderType">
                        <el-select v-model="formAdd.inHolderType" placeholder="请选择" clearable>
                            <el-option label="请选择" value="" />
                            <template v-for="(sole, index) in potTypeList">
                                <el-option v-if="sole.name === '发酵罐'" :key="index" :value="sole.value" :label="sole.name" />
                            </template>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="打入罐号：" prop="inHolderId">
                        <el-select v-model="formAdd.inHolderId" filterable>
                            <el-option v-for="(item, index) in AddPotList" :key="index" :value="item.holderId" :label="item.HOLDER_NAME" />
                        </el-select>
                    </el-form-item>
                    <el-form-item label="物料：">
                        {{ formAdd.materialName }} {{ formAdd.materialCode }}
                    </el-form-item>
                </el-form>
            </div>
            <span slot="footer" class="dialog-footer">
                <el-button size="small" @click="AddDialogTableVisible = false">取消</el-button>
                <el-button type="primary" size="small" @click="FormAddSave('Addstar')">确定</el-button>
            </span>
        </el-dialog>
        <el-dialog :close-on-click-modal="false" :visible.sync="JudgeDialogTableVisible" width="400px" custom-class="dialog__class">
            <div slot="title">
                类别判定
            </div>
            <el-form ref="judge" :model="judge" size="small" label-width="130px" :rules="judgerules">
                <el-form-item label="物料：">
                    {{ judge.materialName }}{{ judge.materialCode }}
                </el-form-item>
                <el-form-item label="发酵天数：">
                    {{ judge.ferDays }} 天
                </el-form-item>
                <el-form-item label="半成品类别：">
                    <el-select v-model="judge.type" placeholder="请选择" style="width: 140px;">
                        <el-option v-for="(item, index) in typeList" :key="index" :label="item.halfType" :value="item.halfType" />
                    </el-select>
                </el-form-item>
                <el-form-item label="状态：">
                    <el-radio v-model="judge.frozenStatus" label="1">
                        正常
                    </el-radio>
                    <el-radio v-model="judge.frozenStatus" label="0">
                        冻结
                    </el-radio>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button size="small" @click="JudgeDialogTableVisible = false">取 消</el-button>
                <el-button type="primary" size="small" @click="FormJudgeSave('judge')">确 定</el-button>
            </span>
        </el-dialog>
        <el-dialog width="450px" class="ShinHoDialog" :title="dialogData.HOLDER_NAME + '清洗'" :close-on-click-modal="false" :visible.sync="visible">
            <div style="display: flex;">
                <el-form :model="dialogData" label-width="100px" class="topform marbottom" style="margin: auto;">
                    <el-form-item label="罐号：">
                        <p>{{ dialogData.HOLDER_NAME }}</p>
                    </el-form-item>
                    <el-form-item label="状态：">
                        <p>待清洗</p>
                    </el-form-item>
                    <el-form-item>
                        <el-checkbox-group v-model="a">
                            <el-checkbox label="清洗完成" name="type" :disabled="true" />
                        </el-checkbox-group>
                    </el-form-item>
                    <el-form-item label="备注：">
                        <el-input v-model="dialogData.remark" size="small" placeholder="手工录入" style="width: 260px;" />
                    </el-form-item>
                    <el-form-item label="录入人员：">
                        {{ $store.state.user.realName + '（' + this.$store.state.user.name + '）' }}
                    </el-form-item>
                    <el-form-item label="录入时间：">
                        {{ newData }}
                    </el-form-item>
                </el-form>
            </div>
            <span slot="footer" class="dialog-footer">
                <el-button size="small" @click="visible = false">取消</el-button>
                <el-button type="primary" size="small" @click="ClearSave(item)">确定</el-button>
            </span>
        </el-dialog>
        <el-dialog :visible.sync="BringOutDialogTableVisible" :close-on-click-modal="false" width="500px" custom-class="dialog__class">
            <div slot="title">
                调整
            </div>
            <div>
                <el-form ref="BringOutstar" size="small" :model="formBringOut" :rules="BringOutrulestar" label-width="150px">
                    <el-form-item label="领用罐号：">
                        {{ formBringOut.holderName }}
                    </el-form-item>
                    <el-form-item label="物料：">
                        {{ formBringOut.materialCode }} {{ formAdd.materialName }}
                    </el-form-item>
                    <el-form-item label="类别：">
                        {{ formBringOut.type }}
                    </el-form-item>
                    <el-form-item label="批次：">
                        {{ formBringOut.batch }}
                    </el-form-item>
                    <el-form-item label="出/入罐：" prop="inType">
                        <el-select v-model="formBringOut.inType" placeholder="请选择" style="width: 200px;" @change="(formBringOut.adjustType = ''), (formBringOut.factoryHolder = ''), (formBringOutLable = '')">
                            <el-option label="出罐" value="2" />
                            <el-option label="入罐" value="1" />
                        </el-select>
                    </el-form-item>
                    <el-form-item label="调整类别：" prop="adjustType">
                        <el-select v-model="formBringOut.adjustType" placeholder="请选择" clearable style="width: 200px;" @change="setPot">
                            <template v-for="(sole, index) in formBringOutType">
                                <el-option v-if="(sole.label === '调配转入' && formBringOut.inType === '1') || (sole.label !== '调配转入' && formBringOut.inType === '2') || sole.label === '其他'" :key="index" :value="sole.value" :label="sole.label" />
                            </template>
                        </el-select>
                    </el-form-item>
                    <el-form-item v-if="formBringOutLable" :label="formBringOutLable + '：'">
                        <el-select v-model="formBringOut.factoryHolder" placeholder="请选择" filterable clearable :disabled="!formBringOutPot.length" style="width: 200px;">
                            <template v-if="formBringOut.adjustType === '调拨'">
                                <el-option v-for="(sole, index) in formBringOutPot" :key="index" :value="sole.code" :label="sole.value" />
                            </template>
                            <template v-if="formBringOut.adjustType === '调配转入'">
                                <el-option v-for="(sole, index) in formBringOutPot" :key="index" :value="sole.holderId" :label="sole.holderName" />
                            </template>
                            <template v-if="formBringOut.adjustType === 'HD'">
                                <el-option v-for="(sole, index) in formBringOutPot" :key="index" :value="sole.holderId" :label="sole.HOLDER_NAME" />
                            </template>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="调整量（L）：" prop="amount">
                        <el-input v-model="formBringOut.amount" style="width: 200px;" />
                    </el-form-item>
                    <el-form-item label="说明：">
                        <el-input v-model="formBringOut.remark" style="width: 200px;" />
                    </el-form-item>
                    <el-form-item label="操作人：">
                        {{ $store.state.user.realName + '（' + this.$store.state.user.name + '）' }}
                    </el-form-item>
                    <el-form-item label="操作时间：">
                        <el-date-picker v-model="formBringOut.bringTime" type="datetime" value-format="yyyy-MM-dd HH:mm" format="yyyy-MM-dd HH:mm" placeholder="请选择" style="width: 199px;" />
                    </el-form-item>
                </el-form>
            </div>
            <span slot="footer" class="dialog-footer">
                <el-button size="small" @click="BringOutDialogTableVisible = false">取消</el-button>
                <el-button type="primary" size="small" @click="FormBringOutSave('BringOutstar')">确定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import { dateFormat } from '@/net/validate';
    import { BASICDATA_API, SYSTEMSETUP_API, JUICE_API } from '@/api/api';
    export default {
        name: 'Index',
        components: {},
        data() {
            const checkreceiveAmount = (rule, value, callback) => {
                if (!value) {
                    return callback(new Error('请填写领用量'));
                } else if (value <= 0) {
                    return callback(new Error('转储量需大于0'));
                }
                callback();
            };
            return {
                formHeader: {
                    factory: '',
                    workShop: '',
                    potType: '',
                    potNo: '',
                    type: '',
                    status: '',
                    dump: '',
                    isF: ''
                },
                isFList: [
                    {
                        name: '正常',
                        value: '0'
                    },
                    {
                        name: 'F0标识',
                        value: '1'
                    },
                    {
                        name: '原汁jbs',
                        value: '2'
                    }
                ],
                potTypeList: [
                    {
                        name: '发酵罐',
                        value: '001'
                    },
                    {
                        name: '原汁罐',
                        value: '013'
                    },
                    {
                        name: 'JBS',
                        value: '016'
                    }
                ],
                factory: [],
                workshop: [],
                holderStatusList: [],
                guanList: [],
                typeList: [],
                dumpList: [
                    {
                        name: '<=25方',
                        value: '<'
                    },
                    {
                        name: '>25方',
                        value: '>'
                    }
                ],
                pages: {
                    currentPage: 1,
                    pageSize: 42,
                    total: 0
                },
                topBox: [
                    {
                        color: '#999999',
                        startColor: '#999999',
                        endColor: '#999999',
                        text: '空',
                        ptext: '空罐',
                        holderStatus: '6',
                        num: '',
                        content: 0
                    },
                    {
                        color: '#B58150',
                        startColor: '#D6D2C4',
                        endColor: '#B58150',
                        text: '6',
                        ptext: '沉淀 0-6天',
                        holderStatus: '',
                        days: [0, 6],
                        num: '',
                        content: 0
                    },
                    {
                        color: '#3F2021',
                        startColor: '#B58150',
                        endColor: '#3F2021',
                        text: '20',
                        ptext: '沉淀 7-20天',
                        holderStatus: '',
                        days: [6, 20],
                        num: '',
                        content: 0
                    },
                    {
                        color: '#C70909',
                        startColor: '#3F2021',
                        endColor: '#C70909',
                        text: '40',
                        ptext: '沉淀 20-40天',
                        holderStatus: '',
                        days: [20, 40],
                        num: '',
                        content: 0
                    },
                    {
                        color: '#8BC34A',
                        startColor: '#C70909',
                        endColor: '#8BC34A',
                        text: '领',
                        ptext: '领用',
                        holderStatus: '9',
                        num: '',
                        content: 0
                    },
                    {
                        color: '',
                        startColor: '#C70909',
                        endColor: '#8BC34A',
                        text: '',
                        ptext: '空罐',
                        holderStatus: '6',
                        num: '',
                        content: 0
                    }
                ],
                holderStatus: '',
                days: '',
                dataListAll: [],
                dataListAlls: [],
                dataList: [],
                TransferDialogTableVisible: false,
                formTransfer: {},
                Transferulestar: {
                    inHolderType: [{ required: true, message: '请选择打入罐类别', trigger: 'blur' }],
                    inHolderId: [{ required: true, message: '请选择打入罐号', trigger: 'blur' }],
                    inBatch: [
                        { required: true, message: '请填写打入批次', trigger: 'blur' },
                        { min: 10, max: 10, message: '批次应为10位数', trigger: 'blur' }
                    ],
                    receiveAmount: [
                        { required: true, message: '请填写领用量', trigger: 'blur' },
                        { validator: checkreceiveAmount, trigger: 'blur' }
                    ]
                },
                AddDialogTableVisible: false,
                formAdd: {},
                todays: '',
                Addrulestar: {
                    amount: [{ required: true, message: '请填写领用量', trigger: 'blur' }],
                    inHolderType: [{ required: true, message: '请选择打入罐类别', trigger: 'blur' }],
                    inHolderId: [{ required: true, message: '请选择打入罐号', trigger: 'blur' }],
                    todays: [{ required: true, message: '请填写发酵天数', trigger: 'blur' }]
                },
                JudgeDialogTableVisible: false,
                judge: {},
                judgerules: {},
                thrwHolderList: [],
                isFullList: [
                    {
                        name: '是',
                        value: '1'
                    },
                    {
                        name: '否',
                        value: '0'
                    }
                ],
                AddPotList: [],
                newData: dateFormat(new Date(), 'yyyy-MM-dd hh:mm:ss'),
                fastS: false,
                visible: false,
                dialogData: {},
                BringOutDialogTableVisible: false,
                BringOutrulestar: {
                    inType: [{ required: true, message: '请填写出/入罐', trigger: 'blur' }],
                    adjustType: [{ required: true, message: '请填写调整类别', trigger: 'blur' }],
                    amount: [{ required: true, message: '请填写领用量', trigger: 'blur' }]
                },
                formBringOut: {},
                formBringOutLable: '',
                formBringOutType: [
                    {
                        label: 'HD',
                        value: 'HD'
                    },
                    {
                        label: '调拨',
                        value: '调拨'
                    },
                    {
                        label: '调配盐水',
                        value: '调配盐水'
                    },
                    {
                        label: '调配转入',
                        value: '调配转入'
                    },
                    {
                        label: '其他',
                        value: '其他'
                    }
                ],
                formBringOutFa: [],
                formBringOutFaPot: [],
                formBringOutTPot: [],
                formBringOutPot: [],
                a: true
            };
        },
        computed: {
            mainTabs: {
                get() {
                    return this.$store.state.common.mainTabs;
                },
                set(val) {
                    this.$store.commit('common/updateMainTabs', val);
                }
            }
        },
        watch: {
            'formHeader.factory'(n) {
                this.formHeader.workShop = '';
                this.formHeader.holderStatus = '';
                this.formHeader.potNo = [];
                this.Getdeptbyid(n);
                this.ChangeSearch();
            },
            'formHeader.workShop'() {
                this.formHeader.potNo = [];
                this.ChangeSearch();
            },
            'formHeader.potType'(n) {
                this.HolderList(n);
            },
            'formTransfer.inHolderType'(n) {
                if (n) {
                    this.formTransfer.inHolderId = '';
                    this.GetRuPotList(n);
                }
                this.formTransfer.inBatch = '';
            },
            'formTransfer.inHolderId'(n) {
                if (n) {
                    this.formTransfer.inBatch = this.thrwHolderList.find(item => item.HOLDER_ID === n).batch;
                }
            }
        },
        mounted() {
            this.Getdeptcode();
            this.GetTypeList();
            this.GetHolderStatusList();
            this.ani();
        },
        methods: {
            setPot(val) {
                this.formBringOut.factoryHolder = '';
                this.formBringOutLable = '';
                if (val === '调拨') {
                    this.formBringOutLable = '工厂';
                    this.formBringOutPot = this.formBringOutFa;
                } else if (val === 'HD') {
                    this.formBringOutLable = '发酵罐';
                    this.formBringOutPot = this.formBringOutFaPot;
                } else if (val === '调配转入') {
                    this.formBringOutLable = '调配罐';
                    this.formBringOutPot = this.formBringOutTPot;
                } else {
                    this.formBringOutLable = '';
                    this.formBringOutPot = [];
                }
            },
            /* eslint-disable no-invalid-this*/
            ani() {
                const $ = this.$;
                this.$('.topBox_boxItem').hover(
                    function() {
                        $(this)
                            .find('.topBox_boxItem_popover')
                            .stop();
                        $(this)
                            .find('.topBox_boxItem_bar_box')
                            .stop();
                        $(this)
                            .find('.topBox_boxItem_popover')
                            .show(500);
                        $(this)
                            .find('.topBox_boxItem_bar_box')
                            .css({ width: 0 });
                        $(this)
                            .find('.topBox_boxItem_tit')
                            .css({ color: '#1890FF' });
                        $(this)
                            .find('.topBox_boxItem_bar_box')
                            .animate({ width: '100%' }, 500);
                        $(this)
                            .parent()
                            .find('.topBox_circle')
                            .css({ transform: 'scale(1.2)' });
                        $(this)
                            .parent()
                            .prev()
                            .find('.topBox_circle')
                            .css({ transform: 'scale(1.2)' });
                    },
                    function() {
                        $(this)
                            .find('.topBox_boxItem_tit')
                            .css({ color: 'black' });
                        $(this)
                            .find('.topBox_boxItem_popover')
                            .hide(500);
                        $(this)
                            .parent()
                            .find('.topBox_circle')
                            .css({ transform: 'scale(1.0)' });
                        $(this)
                            .parent()
                            .prev()
                            .find('.topBox_circle')
                            .css({ transform: 'scale(1.0)' });
                    }
                );
            },
            gotop() {
                const $ = this.$;
                $('.sumbox').stop();
                const hei = $('.sumbox .topBox').height();
                if ($('.sumbox').height()) {
                    $('.sumbox').css({ overflow: 'hidden' });
                    $('.gotop span').text('展开');
                    $('.gotop i').attr('class', 'el-icon-caret-bottom');
                    $('.sumbox').animate({ height: 0 }, 300);
                } else {
                    $('.gotop span').text('收起');
                    $('.gotop i').attr('class', 'el-icon-caret-top');
                    $('.sumbox').animate({ height: `${hei + 35}px` }, 300, function() {
                        $('.sumbox').css({ overflow: 'initial' });
                    });
                }
            },
            /* eslint-enable no-invalid-this*/
            // 总览点击
            topClick(item) {
                this.holderStatus = '';
                this.days = '';
                if (item.holderStatus !== '') {
                    this.holderStatus = item.holderStatus;
                } else {
                    this.days = item.days;
                }
                this.GetPageCurrenList(true);
            },
            // 获取工厂
            Getdeptcode() {
                this.$http(`${BASICDATA_API.FINDORG_API}?code=factory`, 'POST', {}, false, false, false).then(({ data }) => {
                    if (data.code === 0) {
                        this.factory = data.typeList;
                        this.formHeader.factory = data.typeList[0].deptId;
                    } else {
                        this.$errorToast(data.msg);
                    }
                });
            },
            getFa() {
                this.$http(`${SYSTEMSETUP_API.PARAMETERLIST_API}`, 'POST', { type: 'Bring_out_factory' }, false, false, false).then(({ data }) => {
                    if (data.code === 0) {
                        this.formBringOutFa = data.dicList;
                    } else {
                        this.$errorToast(data.msg);
                    }
                });
                this.$http(`${JUICE_API.JUICE_BRINGOUTPROP_FA_LIST}`, 'POST', {}, false, false, false).then(({ data }) => {
                    if (data.code === 0) {
                        this.formBringOutFaPot = data.addPotList;
                    } else {
                        this.$errorToast(data.msg);
                    }
                });
                this.$http(`${JUICE_API.JUICE_BRINGOUTPROP_TIAO_LIST}`, 'POST', {}, false, false, false).then(({ data }) => {
                    if (data.code === 0) {
                        this.formBringOutTPot = data.allocateHolderList;
                    } else {
                        this.$errorToast(data.msg);
                    }
                });
            },
            // 获取车间
            Getdeptbyid(id) {
                if (id) {
                    this.$http(`${BASICDATA_API.FINDORGBYID_API}`, 'POST', { deptId: id, deptName: '原汁' }, false, false, false).then(({ data }) => {
                        if (data.code === 0) {
                            this.workshop = data.typeList;
                            if (data.typeList.length) {
                                this.formHeader.workShop = data.typeList[0].deptId;
                            }
                        } else {
                            this.$errorToast(data.msg);
                        }
                    });
                }
            },
            // 罐号
            HolderList(n) {
                if (n) {
                    this.formHeader.potNo = [];
                    this.$http(`${JUICE_API.JUICE_SEARCH_POT_LIST}`, 'POST', { deptId: this.formHeader.workShop, holderType: n }, false, false, false).then(({ data }) => {
                        this.guanList = data.holderList;
                    });
                }
            },
            // 获取类别
            GetTypeList() {
                this.$http(`${JUICE_API.JUICE_TYPE_LIST}`, 'POST', {}, false, false, false).then(({ data }) => {
                    if (data.code === 0) {
                        this.typeList = data.maintain;
                    } else {
                        this.$errorToast(data.msg);
                    }
                });
            },
            // 获取发酵罐状态
            GetHolderStatusList() {
                this.$http(`${SYSTEMSETUP_API.PARAMETERLIST_API}`, 'POST', { type: 'juice_HOLDER_STATUS' }, false, false, false).then(({ data }) => {
                    if (data.code === 0) {
                        this.holderStatusList = data.dicList;
                    } else {
                        this.$errorToast(data.msg);
                    }
                });
            },
            // 查询
            GetDataList() {
                if (this.formHeader.factory === '') {
                    this.$notify({ title: '警告', message: '请选择工厂', type: 'warning' });
                    return false;
                }
                if (this.formHeader.workShop === '') {
                    this.$notify({ title: '警告', message: '请选择车间', type: 'warning' });
                    return false;
                }
                this.$http(`${JUICE_API.JUICE_POT_LIST}`, 'POST', this.formHeader).then(({ data }) => {
                    if (data.code === 0) {
                        this.fastS = true;
                        this.dataListAll = data.indexList.potList;
                        this.dataListAll.map(item => {
                            item.potColor = '#AD592D';
                        })
                        this.holderStatus = '';
                        this.days = '';
                        this.GetPageCurrenList(true);
                        this.topBox[0].num = data.indexList.summaryData.kong;
                        this.topBox[0].content = data.indexList.summaryData.kongMaintain ? data.indexList.summaryData.kongMaintain : 0;
                        this.topBox[1].num = data.indexList.summaryData.six;
                        this.topBox[1].content = data.indexList.summaryData.sixMaintain ? data.indexList.summaryData.sixMaintain : 0;
                        this.topBox[2].num = data.indexList.summaryData.twenty;
                        this.topBox[2].content = data.indexList.summaryData.twentyMaintain ? data.indexList.summaryData.twentyMaintain : 0;
                        this.topBox[3].num = data.indexList.summaryData.forty;
                        this.topBox[3].content = data.indexList.summaryData.fortyMaintain ? data.indexList.summaryData.fortyMaintain : 0;
                        this.topBox[4].num = data.indexList.summaryData.fortyPlus;
                        this.topBox[4].content = data.indexList.summaryData.fortyPlusMaintain ? data.indexList.summaryData.fortyPlusMaintain : 0;
                        this.topBox[5].num = data.indexList.summaryData.kong;
                        this.topBox[5].content = data.indexList.summaryData.kongMaintain ? data.indexList.summaryData.kongMaintain : 0;
                    } else {
                        this.$errorToast(data.msg);
                    }
                });
            },
            // 转储弹框
            TransferProp(item) {
                if (this.isAuth('juice:pot:List') !== true) {
                    this.$warningToast('没有权限');
                    return false;
                }
                if (item.HOLDER_STATUS === '8' || item.HOLDER_STATUS === '9') {
                    this.$http(`${JUICE_API.JUICE_TRANSFER_LIST}`, 'POST', { holderId: item.HOLDER_ID }, false, false, false).then(({ data }) => {
                        if (data.code === 0) {
                            this.formTransfer = {
                                holderId: item.HOLDER_ID,
                                holderName: item.HOLDER_NAME,
                                materialCode: data.transferStorageList.materialCode,
                                materialName: data.transferStorageList.materialName,
                                type: data.transferStorageList.type,
                                batch: data.transferStorageList.batch,
                                receiveAmount: '',
                                unit: 'L',
                                inHolderId: '',
                                inHolderType: '',
                                isF: '0',
                                inBatch: '',
                                isFull: '0',
                                fullDate: '',
                                remark: '',
                                factory: this.formHeader.factory,
                                workShop: this.formHeader.workShop
                            };
                            this.TransferDialogTableVisible = true;
                        } else {
                            this.$errorToast(data.msg);
                        }
                    });
                } else {
                    this.$notify({ title: '警告', message: '该罐当前不允许转储', type: 'warning' });
                }
            },
            // 转储打入罐号下拉
            GetRuPotList(holderType) {
                this.$http(`${JUICE_API.JUICE_TRANSFER_POT_LIST}`, 'POST', { holderType: holderType }, false, false, false).then(({ data }) => {
                    if (data.code === 0) {
                        this.thrwHolderList = data.transferStoragePotList;
                    } else {
                        this.$errorToast(data.msg);
                    }
                });
            },
            FormTransferSave(formName) {
                this.$refs[formName].validate(valid => {
                    if (valid) {
                        if (this.formTransfer.isFull === '1' && (this.formTransfer.fullDate === '' || !this.formTransfer.fullDate)) {
                            this.$warningToast('满灌时请选择满罐时间');
                            return false;
                        }
                        this.$http(`${JUICE_API.JUICE_TRANSFER_SAVE}`, 'POST', this.formTransfer).then(({ data }) => {
                            if (data.code === 0) {
                                this.$notify({ title: '成功', message: '转储成功', type: 'success' });
                                this.TransferDialogTableVisible = false;
                                this.$refs[formName].resetFields();
                                this.GetDataList(true);
                            } else {
                                this.$errorToast(data.msg);
                            }
                        });
                    } else {
                        return false;
                    }
                });
            },
            AddProp(item) {
                if (this.isAuth('juice:pot:addJuicePot') !== true) {
                    this.$notify({ title: '警告', message: '没有权限', type: 'warning' });
                    return false;
                }
                if (item.HOLDER_STATUS === '9') {
                    this.$http(`${JUICE_API.JUICE_ADD_POT_LIST}`, 'POST', { factory: this.formHeader.factory, workShop: this.formHeader.workShop }, false, false, false).then(({ data }) => {
                        if (data.code === 0) {
                            this.AddPotList = data.addPotList;
                            this.formAdd = {
                                holderId: item.HOLDER_ID,
                                holderName: item.HOLDER_NAME,
                                materialCode: item.MATERIAL_CODE,
                                materialName: item.MATERIAL_NAME,
                                type: item.TYPE,
                                batch: item.BATCH,
                                amount: '',
                                unit: 'L',
                                isF: '0',
                                inHolderType: '',
                                inHolderId: '',
                                inBatch: '',
                                isFull: '',
                                remark: '',
                                factory: this.formHeader.factory,
                                workShop: this.formHeader.workShop
                            };
                            this.AddDialogTableVisible = true;
                        } else {
                            this.$errorToast(data.msg);
                        }
                    });
                } else {
                    this.$notify({ title: '警告', message: '该罐当前不允许进行HD操作', type: 'warning' });
                }
            },
            FormAddSave(formName) {
                this.$refs[formName].validate(valid => {
                    if (valid) {
                        this.$http(`${JUICE_API.JUICE_ADD_SAVE}`, 'POST', this.formAdd).then(({ data }) => {
                            if (data.code === 0) {
                                this.$notify({ title: '成功', message: 'HD操作成功', type: 'success' });
                                this.AddDialogTableVisible = false;
                                this.$refs[formName].resetFields();
                                this.GetDataList(true);
                            } else {
                                this.$errorToast(data.msg);
                            }
                        });
                    } else {
                        return false;
                    }
                });
            },
            JuiceJudgeProp(item) {
                if (this.isAuth('juice:pot:juiceJudge') !== true) {
                    this.$notify({ title: '警告', message: '没有权限', type: 'warning' });
                    return false;
                }
                if (item.HOLDER_STATUS === '6' || item.HOLDER_STATUS === '10') {
                    this.$notify({ title: '警告', message: '该罐当前不允许判定', type: 'warning' });
                    return false;
                }
                this.$http(`${JUICE_API.JUICE_JUICEINFO_LIST}`, 'POST', { holderId: item.HOLDER_ID }, false, false, false).then(({ data }) => {
                    if (data.code === 0) {
                        if (data.juiceJudgeList !== null) {
                            this.judge = {
                                holderId: item.HOLDER_ID,
                                materialCode: item.MATERIAL_CODE,
                                materialName: item.MATERIAL_NAME,
                                oldType: item.TYPE,
                                type: data.juiceJudgeList.TYPE,
                                ferDays: item.days,
                                remark: '',
                                frozenStatus: data.juiceJudgeList.FROZEN_STATUS
                            };
                        } else {
                            this.judge = {
                                holderId: item.HOLDER_ID,
                                materialCode: item.MATERIAL_CODE,
                                materialName: item.MATERIAL_NAME,
                                oldType: item.TYPE,
                                type: '',
                                ferDays: item.days,
                                remark: '',
                                frozenStatus: '1'
                            };
                        }
                        this.JudgeDialogTableVisible = true;
                    } else {
                        this.$errorToast(data.msg);
                    }
                });
            },
            FormJudgeSave(formName) {
                this.$refs[formName].validate(valid => {
                    if (valid) {
                        this.$http(`${JUICE_API.JUICE_JUICEJUDGE_SAVE}`, 'POST', this.judge).then(({ data }) => {
                            if (data.code === 0) {
                                this.$notify({ title: '成功', message: '判定成功', type: 'success' });
                                this.JudgeDialogTableVisible = false;
                                this.$refs[formName].resetFields();
                                this.GetDataList(true);
                            } else {
                                this.$errorToast(data.msg);
                            }
                        });
                    } else {
                        return false;
                    }
                });
            },
            ClearProp(item) {
                if (this.isAuth('juice:pot:juiceClean') !== true) {
                    this.$notify({ title: '警告', message: '没有权限', type: 'warning' });
                    return false;
                }
                if (item.HOLDER_STATUS === '10') {
                    this.dialogData = {
                        HOLDER_NAME: item.HOLDER_NAME,
                        holderId: item.HOLDER_ID,
                        remark: '',
                        holderType: item.HOLDER_TYPE
                    };
                    this.visible = true;
                } else {
                    this.$notify({ title: '警告', message: '该罐当前不允许清洗', type: 'warning' });
                }
            },
            ClearSave() {
                this.$http(`${JUICE_API.JUICE_JUICE_CLEAN}`, 'POST', this.dialogData).then(({ data }) => {
                    if (data.code === 0) {
                        this.$notify({ title: '成功', message: '清洗成功', type: 'success' });
                        this.GetDataList(true);
                        this.visible = false;
                    } else {
                        this.$errorToast(data.msg);
                    }
                });
            },
            BringOutProp(item) {
                if (this.isAuth('juice:pot:juiceBringOut') !== true) {
                    this.$notify({ title: '警告', message: '没有权限', type: 'warning' });
                    return false;
                }
                if (item.HOLDER_STATUS === '6') {
                    this.$notify({ title: '警告', message: '该罐当前不允许调整', type: 'warning' });
                } else {
                    this.BringOutDialogTableVisible = true;
                    this.formBringOut = {
                        holderName: item.HOLDER_NAME,
                        holderId: item.HOLDER_ID,
                        materialCode: item.MATERIAL_CODE,
                        materialName: item.MATERIAL_NAME,
                        type: item.TYPE,
                        inType: item.inType,
                        factoryHolder: item.factoryHolder,
                        adjustType: item.adjustType,
                        batch: item.BATCH,
                        bringTime: dateFormat(new Date(), 'yyyy-MM-dd hh:mm:ss'),
                        amount: '',
                        remark: ''
                    };
                    this.getFa();
                }
            },
            FormBringOutSave(formName) {
                this.$refs[formName].validate(valid => {
                    if (valid) {
                        if (this.formBringOut.adjustType === '其他') {
                            if (!this.formBringOut.remark) {
                                this.$notify({ title: '警告', message: '说明必填', type: 'warning' });
                                return false;
                            }
                        }
                        this.$http(`${JUICE_API.JUICE_JUICE_BRINGOUT_SAVE}`, 'POST', this.formBringOut).then(({ data }) => {
                            if (data.code === 0) {
                                this.$notify({ title: '成功', message: '调整成功', type: 'success' });
                                this.BringOutDialogTableVisible = false;
                                this.$refs[formName].resetFields();
                                this.GetDataList(true);
                            } else {
                                this.$errorToast(data.msg);
                            }
                        });
                    } else {
                        return false;
                    }
                });
            },
            // 去详请
            godetails(row) {
                this.$store.state.common.Juice = row;
                this.mainTabs = this.mainTabs.filter(item => item.name !== 'DataEntry-Juice-Pot-detail');
                setTimeout(() => {
                    this.$router.push({ name: `DataEntry-Juice-Pot-detail` });
                }, 100);
            },
            // 改变每页条数
            handleSizeChange(val) {
                this.pages.pageSize = val;
                this.GetPageCurrenList();
            },
            // 跳转页数
            handleCurrentChange(val) {
                this.pages.currentPage = val;
                this.GetPageCurrenList();
            },
            GetPageCurrenList(ty) {
                if (ty === true) {
                    this.pages.currentPage = 1;
                }
                this.dataListAlls = [];
                this.dataList = [];
                if (this.holderStatus !== '' || this.days !== '') {
                    this.dataListAll.map(item => {
                        if (this.holderStatus !== '') {
                            if (item.HOLDER_STATUS === this.holderStatus) {
                                this.dataListAlls.push(item);
                            }
                        } else if (this.days !== '') {
                            if (this.days[0] <= parseInt(item.days, 10) && parseInt(item.days, 10) < this.days[1] && item.HOLDER_STATUS !== '6') {
                                this.dataListAlls.push(item);
                            }
                        }
                        // if (this.holderStatus !== '' && item.holderStatus === '6') {
                        //   this.dataListAlls.push(item)
                        // }
                        // if (this.days !== '') {
                        //   if (this.days[0] <= parseInt(item.days) && parseInt(item.days) < this.days[1]) {
                        //     this.dataListAlls.push(item)
                        //   }
                        // }
                    });
                } else {
                    this.dataListAlls = this.dataListAll;
                }
                this.pages.total = this.dataListAlls.length;
                this.dataList = this.dataListAlls.slice((this.pages.currentPage - 1) * this.pages.pageSize, (this.pages.currentPage - 1) * this.pages.pageSize + this.pages.pageSize);
            },
            // 更改头部查询信息
            ChangeSearch() {
                this.fastS = false;
            }
        }
    };
</script>

<style>
    .dataList_item .el-card__body {
        padding: 0 !important;
    }
</style>
<style lang="scss" scoped>
    .ferCard {
        .el-card__body {
            padding: 7px;
        }
        .cardTit {
            padding-bottom: 10px;
            color: black;
            font-weight: 400;
            font-size: 16px;
            border-bottom: 1px solid #e9e9e9;
        }
        .gotop {
            float: right;
            color: #1890ff;
            font-size: 14px;
            cursor: pointer;
            em {
                ::before {
                    color: #1890ff;
                }
            }
        }
    }
    .topBox {
        width: 1142px;
        margin: auto;
        padding: 25px 25px 10px;
        &_boxItem {
            position: relative;
            float: left;
            width: 155px;
            cursor: pointer;
            &_bar {
                width: 140px;
                height: 2px;
                margin: 15px 8px 0;
                background: #f2f2f2;
                &_box {
                    height: 2px;
                }
            }
            &_tit {
                margin-top: 10px;
                color: black;
                font-size: 16px;
                line-height: 32px;
                text-align: center;
            }
            &_detail {
                color: #666;
                font-size: 14px;
                text-align: center;
                span {
                    color: black;
                }
            }
            &_popover {
                position: absolute;
                top: -60px;
                z-index: 999999;
                display: none;
                min-width: 150px;
                min-height: 52px;
                padding: 5px;
                font-size: 13px;
                line-height: 18px;
                background: white;
                border-radius: 4px;
                box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.3);
                .dot {
                    float: left;
                    width: 6px;
                    height: 6px;
                    margin: 4px 5px 0 0;
                    border-radius: 50%;
                }
                &_ar {
                    position: absolute;
                    bottom: -12px;
                    width: 0;
                    height: 0;
                    border-color: #fff transparent transparent;
                    border-style: solid;
                    border-width: 6px;
                }
            }
        }
        &_circle {
            float: left;
            width: 32px;
            height: 32px;
            color: white;
            line-height: 32px;
            text-align: center;
            background: #999;
            border-radius: 50%;
            transition: all 0.5s;
        }
    }

    .buttonCss .el-button--primary:first-child {
        color: #000;
        background-color: #fff;
        border-color: #d9d9d9;
    }
    .buttonCss .el-button--primary:hover {
        color: #fff;
        background-color: #1890ff;
    }
</style>
