<template>
    <div class="header_main">
        <el-card class="searchCards searchCard">
            <el-row type="flex">
                <el-col>
                    <el-form :model="plantList" size="small" :inline="true" label-position="right" label-width="70px" class="maintain multi_row">
                        <el-form-item label="生产工厂：">
                            <el-select v-model="plantList.factory" placeholder="请选择">
                                <el-option label="请选择" value="" />
                                <el-option v-for="(item, index) in factory" :key="index" :label="item.deptName" :value="item.deptId" />
                            </el-select>
                        </el-form-item>
                        <el-form-item label="生产车间：">
                            <el-select v-model="plantList.workshop" placeholder="请选择">
                                <el-option label="请选择" value="" />
                                <el-option v-for="(item, index) in workshop" :key="index" :label="item.deptName" :value="item.deptId" />
                            </el-select>
                        </el-form-item>
                        <el-form-item label="产线：">
                            <el-select v-model="plantList.productline" placeholder="产线">
                                <el-option label="请选择" value="" />
                                <el-option v-for="(item, index) in productline" :key="index" :label="item.deptName" :value="item.deptId" />
                            </el-select>
                        </el-form-item>
                        <el-form-item label="订单号：">
                            <el-input v-model="plantList.orderNo" placeholder="订单号" />
                        </el-form-item>
                        <el-form-item label="日期：">
                            <el-date-picker v-model="plantList.productdate" type="date" placeholder="选择" value-format="yyyy-MM-dd HH:mm:ss" />
                        </el-form-item>
                        <el-form-item class="floatr">
                            <el-button type="primary" size="small" @click="GetMaintainList(true)">
                                查询
                            </el-button>
                        </el-form-item>
                    </el-form>
                </el-col>
            </el-row>
        </el-card>
        <mds-card title="立体库" name="noMaintainList" :pack-up="false" style="margin-top: 10px;">
            <el-table ref="maintain" class="newTable" header-row-class-name="tableHead" :data="noMaintainList" border tooltip-effect="dark" style="width: 100%;" @selection-change="handleSelectionChange">
                <el-table-column type="selection" :selectable="checkboxT" width="50" fixed />
                <el-table-column type="index" width="55" label="序号" fixed />
                <el-table-column prop="orderNo" label="生产订单号" :show-overflow-tooltip="true" width="120" />
                <el-table-column label="品项" :show-overflow-tooltip="true" width="300">
                    <template slot-scope="scope">
                        {{ scope.row.materialCode + ' ' + scope.row.materialName }}
                    </template>
                </el-table-column>
                <el-table-column prop="batch" label="生产批次" width="120" />
                <el-table-column prop="aiShelves" label="自动上架数-立体库" width="140" />
                <el-table-column prop="aiShelvesUnitName" label="单位" width="50" />
                <el-table-column label="车间确认人" :show-overflow-tooltip="true" width="92">
                    <template slot-scope="scope">
                        {{ scope.row.workShopMan }}
                    </template>
                </el-table-column>
                <el-table-column label="机维组确认整板数" width="135">
                    <template slot-scope="scope">
                        <el-input v-if="scope.row.redact" v-model="scope.row.jwzZb" size="small" />
                        <span v-if="!scope.row.redact">{{ scope.row.jwzZb }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="机维组确认半板数" width="135">
                    <template slot-scope="scope">
                        <el-input v-if="scope.row.redact" v-model="scope.row.jwzBb" size="small" />
                        <span v-if="!scope.row.redact">{{ scope.row.jwzBb }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="机维组确认数" width="107">
                    <template slot-scope="scope">
                        <span>{{ (scope.row.jwzAcount = scope.row.jwzBb * 1 + scope.row.jwzZb * 1) }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="差异数量" width="78">
                    <template slot-scope="scope">
                        <span>{{ (scope.row.different = scope.row.jwzAcount * 1 - scope.row.aiShelves * 1) }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="单位" width="50">
                    <template slot-scope="scope">
                        <span>{{ scope.row.differentUnitName }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="原差异数量" width="92">
                    <template slot-scope="scope">
                        <el-input v-if="scope.row.redact" v-model="scope.row.orgnDifferent" size="small" />
                        <span v-else>{{ scope.row.orgnDifferent }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="差异说明" :show-overflow-tooltip="true" width="78">
                    <template slot-scope="scope">
                        <el-input v-if="scope.row.redact" v-model="scope.row.differentInfo" size="small" />
                        <span v-else>{{ scope.row.differentInfo }}</span>
                    </template>
                </el-table-column>
                <el-table-column prop="jwzMan" label="机维组确认人" width="140" />
                <el-table-column label="备注" :show-overflow-tooltip="true">
                    <template slot-scope="scope">
                        <span>{{ scope.row.remark }}</span>
                    </template>
                </el-table-column>
                <el-table-column fixed="right" prop="address" label="操作" width="50">
                    <template slot-scope="scope">
                        <el-button v-if="isAuth('sys:verifyJWZ:update') && scope.row.status !== 'finished' && scope.row.aiShelves !== 0" style="padding: 0;" type="text" size="small" @click="redact(scope.row)">
                            {{ scope.row.redact ? '保存' : '编辑' }}
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
            <el-row>
                <el-pagination :current-page="plantList.currPage" :page-sizes="[10, 20, 50]" :page-size="plantList.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="plantList.totalCount" @size-change="handleSizeChange" @current-change="handleCurrentChange" />
            </el-row>
        </mds-card>
        <redact-box>
            <template slot="button">
                <el-button v-if="isAuth('sys:verifyJWZ:update')" type="primary" size="small" @click="save()">
                    保存
                </el-button>
                <el-button v-if="isAuth('sys:verifyJWZ:finished')" type="primary" size="small" @click="submit()">
                    提交
                </el-button>
            </template>
        </redact-box>
    </div>
</template>

<script>
import { BASICDATA_API, MAINTAIN_API } from '@/api/api';
import { headanimation } from '@/net/validate';
export default {
    name: 'Index',
    components: {},
    data() {
        return {
            factory: [],
            workshop: [],
            productline: [],
            plantList: {
                status: 'checked',
                orderNo: '',
                factory: '',
                workshop: '',
                productline: '',
                productdate: '',
                currPage: 1,
                pageSize: 10,
                totalCount: 0
            },
            MaintainList: [],
            noMaintainList: []
        };
    },
    computed: {},
    watch: {
        'plantList.factory'(n) {
            this.Getdeptbyid(n);
        },
        'plantList.workshop'(n) {
            if (n) {
                this.GetParentline(n);
            }
        }
    },
    mounted() {
        // this.GetMaintainList()
        this.Getdeptcode();
        headanimation(this.$);
    },
    methods: {
        // 获取列表
        GetMaintainList(st) {
            if (st) {
                this.plantList.currPage = 1;
            }
            this.$http(`${MAINTAIN_API.MAINTAINLIST_API}`, 'POST', this.plantList).then(({ data }) => {
                if (data.code === 0) {
                    this.noMaintainList = data.page.list;
                    this.plantList.currPage = data.page.currPage;
                    this.plantList.pageSize = data.page.pageSize;
                    this.plantList.totalCount = data.page.totalCount;
                } else {
                    this.$errorToast(data.msg);
                }
            });
        },
        // 获取工厂
        Getdeptcode() {
            this.$http(`${BASICDATA_API.FINDORG_API}?code=factory`, 'POST').then(({ data }) => {
                if (data.code === 0) {
                    this.factory = data.typeList;
                    if (!this.plantList.factory && data.typeList.length > 0) {
                        this.plantList.factory = data.typeList[0].deptId;
                    }
                } else {
                    this.$errorToast(data.msg);
                }
            });
        },
        // 获取车间
        Getdeptbyid(id) {
            this.plantList.workshop = '';
            this.plantList.productline = '';
            if (id) {
                this.$http(`${BASICDATA_API.FINDORGBYID_API}`, 'POST', {
                    deptId: id,
                    deptName: '包装 组装'
                }).then(({ data }) => {
                    if (data.code === 0) {
                        this.workshop = data.typeList;
                        if (!this.plantList.workshop && data.typeList.length > 0) {
                            this.plantList.workshop = data.typeList[0].deptId;
                        }
                    } else {
                        this.$errorToast(data.msg);
                    }
                });
            }
        },
        // 获取产线
        GetParentline(id) {
            this.plantList.productline = '';
            if (id) {
                this.$http(`${BASICDATA_API.FINDORGBYPARENTID_API}`, 'POST', {
                    parentId: id
                }).then(({ data }) => {
                    if (data.code === 0) {
                        this.productline = data.childList;
                    } else {
                        this.$errorToast(data.msg);
                    }
                });
            }
        },
        // 表格选中
        handleSelectionChange(val) {
            this.MaintainList = [];
            val.forEach((item) => {
                this.MaintainList.push(item);
            });
        },
        // 审核通过禁用
        checkboxT(row) {
            if (row.status === 'finished' || row.aiShelves === 0) {
                return 0;
            }
                return 1;

        },
        // 校验校验
        getverify() {
            let ty = true;
            this.MaintainList.forEach(item => {
                if (item.different !== 0 || item.orgnDifferent) {
                    if (!item.differentInfo) {
                        ty = false;
                    }
                }
            });
            return ty;
        },
        getverify1() {
            let ty = true;
            this.MaintainList.forEach(item => {
                if (Number(item.aiShelves) !== Number(item.jwzAcount)) {
                    ty = false;
                }
            });
            return ty;
        },
        // 编辑
        redact(row) {
            if (!row.redact) {
                row.redact = true;
                this.noMaintainList.splice(this.noMaintainList.length, 0, {});
                this.noMaintainList.splice(this.noMaintainList.length - 1, 1);
            } else {
                if (row.different !== 0 || row.orgnDifferent) {
                    if (!row.differentInfo) {
                        this.$warningToast('差异说明必填');
                        return false;
                    }
                }
                row.postgDate = this.plantList.postgDate;
                row.status = '';
                this.$http(`${MAINTAIN_API.MAINTAINSAVE_API}`, 'POST', [row]).then(({ data }) => {
                    if (data.code === 0) {
                        this.$notify({
                            title: '成功',
                            message: '操作成功',
                            type: 'success'
                        });
                        row.redact = false;
                        this.noMaintainList.splice(this.noMaintainList.length, 0, {});
                        this.noMaintainList.splice(this.noMaintainList.length - 1, 1);
                    } else {
                        this.$errorToast(data.msg);
                    }
                });
            }
        },
        // 保存
        save() {
            if (this.MaintainList.length > 0) {
                if (!this.getverify()) {
                    this.$warningToast('差异说明必填');
                    return false;
                }
                this.$confirm('确认保存, 是否继续?', '保存', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$http(`${MAINTAIN_API.MAINTAINSAVE_API}`, 'POST', this.MaintainList).then(({ data }) => {
                        if (data.code === 0) {
                            this.$notify({
                                title: '成功',
                                message: '保存成功',
                                type: 'success'
                            });
                            this.GetMaintainList();
                        } else {
                            this.$errorToast(data.msg);
                        }
                    });
                    this.GetMaintainList();
                }).catch(() => {
                    // this.$infoToast('已取消删除');
                });
            } else {
                this.$warningToast('请勾选后保存');
            }
        },
        // 提交
        submit() {
            if (this.MaintainList.length > 0) {
                if (!this.getverify()) {
                    this.$warningToast('差异说明必填');
                    return false;
                }
                if (!this.getverify1()) {
                    this.$warningToast('车间入库数与机维组确认数不一致，请重新录入数据！');
                    return false;
                }
                this.$confirm('确认提交, 是否继续?', '提交', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$http(`${MAINTAIN_API.MAINTAINSUB_API}`, 'POST', this.MaintainList).then(({ data }) => {
                        if (data.code === 0) {
                            this.$notify({
                                title: '成功',
                                message: '提交成功',
                                type: 'success'
                            });
                            this.GetMaintainList();
                        } else {
                            this.$errorToast(data.msg);
                        }
                    });
                }).catch(() => {
                    // this.$infoToast('已取消删除');
                });
            } else {
                this.$warningToast('请勾选后保存');
            }
        },
        // 改变每页条数
        handleSizeChange(val) {
            this.plantList.pageSize = val;
            this.GetMaintainList();
        },
        // 跳转页数
        handleCurrentChange(val) {
            this.plantList.currPage = val;
            this.GetMaintainList();
        }
    }
};
</script>

<style lang="scss" scoped></style>
<style lang="scss">
.searchCard {
    margin-bottom: 0;
}
.searchCard,
.tableCard {
    position: relative;
    .toggleSearchTop {
        position: absolute;
        top: 0;
        left: 0;
        display: none;
        width: 100%;
        text-align: center;
        cursor: pointer;
    }
    .toggleSearchBottom {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        text-align: center;
        cursor: pointer;
    }
    .el-icon-caret-top::before,
    .el-icon-caret-bottom::before {
        color: #dcdfe6;
    }
}

.maintain {
    .el-date-editor.el-input,
    input {
        width: 180px !important;
    }
}
</style>
