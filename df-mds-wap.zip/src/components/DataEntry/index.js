import DataEntry from './DataEntry';

export default function(Vue) {
    Vue.component('DataEntry', DataEntry);
}
