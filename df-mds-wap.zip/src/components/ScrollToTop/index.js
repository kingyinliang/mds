import ScrollToTop from './ScrollToTop';

export default function(Vue) {
    Vue.component('ScrollTop', ScrollToTop);
}
